//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BQZFeh-6.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/courses",
			"/diagnose",
			"/onboard",
			"/progress",
			"/quiz/$quizId",
			"/results/$attemptId"
		],
		preloads: [
			"/assets/index-nrqUqB_N.js",
			"/assets/useRouter-ByJ6_rwb.js",
			"/assets/not-found-DIgawKw1.js",
			"/assets/preload-helper-Dr9jVG1s.js",
			"/assets/link-Dl8U-TA0.js",
			"/assets/matchContext-BZw_idz-.js",
			"/assets/useSelector-C0SCdirR.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-nrqUqB_N.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CpDN-bgl.js",
			"/assets/badge-Dum8Q-YG.js",
			"/assets/button-uBpMc2o7.js",
			"/assets/course-card-BKMhkA8P.js",
			"/assets/card-CvgFs5Wg.js"
		]
	},
	"/courses": {
		filePath: "/workspace/src/routes/courses.tsx",
		children: ["/courses/$courseId", "/courses/"],
		preloads: ["/assets/courses-9lZ3WE1e.js"]
	},
	"/diagnose": {
		filePath: "/workspace/src/routes/diagnose.tsx",
		children: void 0,
		preloads: [
			"/assets/diagnose-CaPAcxdc.js",
			"/assets/useNavigate-B4d63ntE.js",
			"/assets/badge-Dum8Q-YG.js",
			"/assets/button-uBpMc2o7.js",
			"/assets/input-DPuGcrpI.js",
			"/assets/card-CvgFs5Wg.js",
			"/assets/quiz-engine-DPbgl3Fp.js"
		]
	},
	"/onboard": {
		filePath: "/workspace/src/routes/onboard.tsx",
		children: void 0,
		preloads: [
			"/assets/onboard-CU4PpCKc.js",
			"/assets/useNavigate-B4d63ntE.js",
			"/assets/button-uBpMc2o7.js",
			"/assets/input-DPuGcrpI.js",
			"/assets/card-CvgFs5Wg.js"
		]
	},
	"/progress": {
		filePath: "/workspace/src/routes/progress.tsx",
		children: void 0,
		preloads: [
			"/assets/progress-BIgildEO.js",
			"/assets/badge-Dum8Q-YG.js",
			"/assets/button-uBpMc2o7.js",
			"/assets/card-CvgFs5Wg.js"
		]
	},
	"/courses/$courseId": {
		filePath: "/workspace/src/routes/courses.$courseId.tsx",
		children: void 0,
		preloads: [
			"/assets/courses._courseId-Ft4isNUN.js",
			"/assets/check-Cs3PLiTi.js",
			"/assets/clock-COBM2PMT.js",
			"/assets/badge-Dum8Q-YG.js",
			"/assets/button-uBpMc2o7.js"
		]
	},
	"/quiz/$quizId": {
		filePath: "/workspace/src/routes/quiz.$quizId.tsx",
		children: void 0,
		preloads: [
			"/assets/quiz._quizId-BJg-clZC.js",
			"/assets/useNavigate-B4d63ntE.js",
			"/assets/button-uBpMc2o7.js",
			"/assets/card-CvgFs5Wg.js",
			"/assets/quiz-engine-DPbgl3Fp.js"
		]
	},
	"/results/$attemptId": {
		filePath: "/workspace/src/routes/results.$attemptId.tsx",
		children: void 0,
		preloads: [
			"/assets/results._attemptId-DQoXWEOn.js",
			"/assets/check-Cs3PLiTi.js",
			"/assets/badge-Dum8Q-YG.js",
			"/assets/button-uBpMc2o7.js",
			"/assets/course-card-BKMhkA8P.js",
			"/assets/card-CvgFs5Wg.js",
			"/assets/quiz-engine-DPbgl3Fp.js"
		]
	},
	"/courses/": {
		filePath: "/workspace/src/routes/courses.index.tsx",
		children: void 0,
		preloads: [
			"/assets/courses.index-9rBvfzO2.js",
			"/assets/course-card-BKMhkA8P.js",
			"/assets/input-DPuGcrpI.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
