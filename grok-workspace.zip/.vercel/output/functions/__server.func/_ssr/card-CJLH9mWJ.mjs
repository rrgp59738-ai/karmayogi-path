import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as cn } from "./router-C5Kd15x_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/card-CJLH9mWJ.js
var import_jsx_runtime = require_jsx_runtime();
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-xl bg-paper-raised p-5 shadow-border md:p-6", className),
		...props
	});
}
//#endregion
export { Card as t };
