import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useNavigate, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as cn, o as useAppStore, r as Route$1, s as useHydrated } from "./router-C5Kd15x_.mjs";
import { t as Button } from "./button-BjATLKEN.mjs";
import { i as scoreAttempt } from "./quiz-engine-DNPRNqzs.mjs";
import { t as Card } from "./card-CJLH9mWJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz._quizId-D8DYibdV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuizPage() {
	const { quizId } = Route$1.useParams();
	const navigate = useNavigate();
	const hydrated = useHydrated();
	const activeQuiz = useAppStore((s) => s.activeQuiz);
	const saveAttempt = useAppStore((s) => s.saveAttempt);
	const quiz = activeQuiz?.id === quizId ? activeQuiz : null;
	const [index, setIndex] = (0, import_react.useState)(0);
	const [answers, setAnswers] = (0, import_react.useState)([]);
	const filled = (0, import_react.useMemo)(() => {
		if (!quiz) return answers;
		if (answers.length === quiz.questions.length) return answers;
		return [...answers, ...Array(quiz.questions.length - answers.length).fill(null)];
	}, [answers, quiz]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse rounded-xl bg-navy/8" });
	if (!quiz) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg space-y-4 py-12 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold text-navy",
				children: "This paper has expired"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Diagnostics live only for the sitting. Start a new one from the desk."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/diagnose",
					children: "Back to diagnose"
				})
			})
		]
	});
	const question = quiz.questions[index];
	const selected = filled[index];
	const last = index === quiz.questions.length - 1;
	const letters = [
		"A",
		"B",
		"C",
		"D"
	];
	function choose(optionIndex) {
		setAnswers((prev) => {
			const next = [...filled];
			next[index] = optionIndex;
			return next;
		});
	}
	function submit() {
		if (!quiz) return;
		const scored = scoreAttempt(quiz.questions, filled);
		const attempt = {
			id: crypto.randomUUID(),
			quiz,
			answers: filled,
			score: scored.score,
			weakTopics: scored.weakTopics,
			completedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		saveAttempt(attempt);
		navigate({
			to: "/results/$attemptId",
			params: { attemptId: attempt.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-[0.2em] text-saffron",
					children: quiz.source === "ai" ? "Grok paper" : "Curated paper"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-2xl font-semibold text-navy md:text-3xl",
					children: quiz.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"Question ",
						index + 1,
						" of ",
						quiz.questions.length
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-1.5 overflow-hidden rounded-full bg-navy/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-saffron transition-[width] duration-200 ease-out",
						style: { width: `${(index + 1) / quiz.questions.length * 100}%` }
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl font-medium leading-snug text-navy",
					children: question.stem
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2",
					children: question.options.map((opt, i) => {
						const on = selected === i;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => choose(i),
							className: cn("flex min-h-14 items-start gap-3 rounded-md px-4 py-3 text-left text-sm leading-relaxed shadow-border transition-colors duration-150", on ? "bg-navy text-primary-foreground" : "bg-paper hover:bg-paper-raised"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full text-xs font-semibold", on ? "bg-saffron text-saffron-fg" : "bg-navy/8 text-navy"),
								children: letters[i]
							}), opt]
						}, opt);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "flex-1",
					disabled: index === 0,
					onClick: () => setIndex((i) => Math.max(0, i - 1)),
					children: "Previous"
				}), last ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "saffron",
					className: "flex-1",
					disabled: selected === null || selected === void 0,
					onClick: submit,
					children: "Submit paper"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "flex-1",
					disabled: selected === null || selected === void 0,
					onClick: () => setIndex((i) => i + 1),
					children: "Next"
				})]
			})
		]
	});
}
//#endregion
export { QuizPage as component };
