import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as competencyById } from "./catalog-7qHhzf7T.mjs";
import { d as Check, t as X } from "../_libs/lucide-react.mjs";
import { c as coursesForCompetency, d as cn, n as Route, o as useAppStore, s as useHydrated } from "./router-C5Kd15x_.mjs";
import { t as Badge } from "./badge-CUilnUdH.mjs";
import { t as Button } from "./button-BjATLKEN.mjs";
import { t as CourseCard } from "./course-card-41d8qhbq.mjs";
import { i as scoreAttempt } from "./quiz-engine-DNPRNqzs.mjs";
import { t as Card } from "./card-CJLH9mWJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/results._attemptId-P-o4Si5i.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResultsPage() {
	const { attemptId } = Route.useParams();
	const hydrated = useHydrated();
	const attempt = useAppStore((s) => s.attempts).find((a) => a.id === attemptId);
	const [open, setOpen] = (0, import_react.useState)(null);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse rounded-xl bg-navy/8" });
	if (!attempt) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg space-y-4 py-12 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl font-semibold text-navy",
			children: "Result not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/diagnose",
				children: "Sit another diagnostic"
			})
		})]
	});
	const detail = scoreAttempt(attempt.quiz.questions, attempt.answers);
	const recs = [...new Set(attempt.quiz.questions.map((q) => q.competencyId))].flatMap((id) => coursesForCompetency(id)).slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-navy px-6 py-8 text-primary-foreground md:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.2em] text-saffron",
						children: "Result"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl font-semibold",
						children: attempt.quiz.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 font-display text-5xl font-semibold tabular-nums",
						children: [attempt.score, "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-primary-foreground/70",
						children: [
							detail.correct,
							" of ",
							attempt.quiz.questions.length,
							" correct"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-3 inline-block rounded-full bg-primary-foreground/12 px-3 py-1 text-xs",
						children: attempt.score >= 75 ? "Proficient sitting" : attempt.score >= 50 ? "Developing" : "Needs work"
					}),
					attempt.weakTopics.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 flex flex-wrap gap-2",
						children: attempt.weakTopics.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-primary-foreground/10 px-3 py-1 text-xs",
							children: ["Gap · ", t]
						}, t))
					})
				]
			}),
			recs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 font-display text-2xl font-semibold text-navy",
				children: "Courses for these gaps"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: recs.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseCard, { course: c }, c.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold text-navy",
					children: "Review"
				}), attempt.quiz.questions.map((q, i) => {
					const chosen = attempt.answers[i];
					const ok = chosen === q.correctIndex;
					const expanded = open === q.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4 md:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full items-start gap-3 text-left",
							onClick: () => setOpen(expanded ? null : q.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full", ok ? "bg-forest/15 text-forest" : "bg-danger/12 text-danger"),
								children: ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-medium leading-snug text-navy",
									children: q.stem
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 flex flex-wrap gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											tone: ok ? "strong" : "weak",
											children: ok ? "Correct" : "Missed"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: competencyById(q.competencyId)?.short }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											tone: "saffron",
											children: q.topicTag
										})
									]
								})]
							})]
						}), expanded && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-2 border-t border-line pt-4 text-sm",
							children: [q.options.map((opt, oi) => {
								const isCorrect = oi === q.correctIndex;
								const isChosen = oi === chosen;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: cn("rounded-sm px-3 py-2", isCorrect && "bg-forest/10 text-forest", isChosen && !isCorrect && "bg-danger/8 text-danger"),
									children: [opt, isCorrect ? " — key" : isChosen ? " — your answer" : ""]
								}, opt);
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "pt-2 leading-relaxed text-muted",
								children: q.explanation
							})]
						})]
					}, q.id);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/diagnose",
						children: "Another diagnostic"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/progress",
						children: "Open the map"
					})
				})]
			})
		]
	});
}
//#endregion
export { ResultsPage as component };
