import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as cn } from "./router-C5Kd15x_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/input-D2PE5WSI.js
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md border border-line bg-paper-raised px-3 text-base text-ink placeholder:text-muted md:text-sm", className),
		...props
	});
}
function SelectField({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn("h-11 w-full rounded-md border border-line bg-paper-raised px-3 text-base text-ink md:text-sm", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("mb-1.5 block text-sm font-medium text-ink", className),
		...props
	});
}
//#endregion
export { Label as n, SelectField as r, Input as t };
