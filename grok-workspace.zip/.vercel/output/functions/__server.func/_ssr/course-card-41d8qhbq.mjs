import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as LEVEL_LABEL, l as modulesFor, s as competencyById, t as CATEGORY_LABEL } from "./catalog-7qHhzf7T.mjs";
import { l as Clock } from "../_libs/lucide-react.mjs";
import { d as cn } from "./router-C5Kd15x_.mjs";
import { t as Badge } from "./badge-CUilnUdH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/course-card-41d8qhbq.js
var import_jsx_runtime = require_jsx_runtime();
function CourseCard({ course, progress, featured = false }) {
	const total = modulesFor(course.id).length;
	const primary = competencyById(course.competencyIds[0]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/courses/$courseId",
		params: { courseId: course.id },
		className: cn("group flex flex-col rounded-xl bg-paper-raised p-5 shadow-border transition-[box-shadow,transform] duration-150 hover:shadow-[var(--shadow-border-hover)]", featured && "md:p-6"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: CATEGORY_LABEL[course.category] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1 text-xs text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
						course.durationMin,
						" min"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-xl font-semibold tracking-tight text-navy group-hover:text-saffron",
				children: course.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 flex-1 text-sm leading-relaxed text-muted",
				children: course.subtitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap items-center gap-2 text-xs text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: LEVEL_LABEL[course.level] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						children: "·"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: primary?.short }),
					progress && total > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						children: "·"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: progress.done ? "text-forest" : void 0,
						children: progress.done ? "Completed" : `${progress.completed}/${total} modules`
					})] })
				]
			})
		]
	});
}
//#endregion
export { CourseCard as t };
