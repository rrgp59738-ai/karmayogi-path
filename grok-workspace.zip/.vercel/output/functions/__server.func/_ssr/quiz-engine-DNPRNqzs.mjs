import { n as COMPETENCIES, u as roleById } from "./catalog-7qHhzf7T.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz-engine-DNPRNqzs.js
var QUESTION_BANK = [
	{
		id: "eth-1",
		competencyId: "ethics",
		stem: "A vendor who regularly supplies your office sends a hamper to your residence during Diwali. The value is above the token limit in the Conduct Rules. What is the correct first step?",
		options: [
			"Accept it as customary hospitality and note it mentally",
			"Refuse or return it, and record the offer on the file / in a disclosure",
			"Accept it but donate the contents to the staff welfare club without a record",
			"Ask the vendor to send a smaller hamper next year"
		],
		correctIndex: 1,
		explanation: "Gifts above the permitted token value must not be accepted. Returning or refusing, and recording the offer, protects you and the office. Informal ‘donation’ still leaves a trail of influence with no disclosure.",
		topicTag: "Gifts and hospitality",
		difficulty: "foundation"
	},
	{
		id: "eth-2",
		competencyId: "ethics",
		stem: "Your spouse is a director in a firm that has bid for a consultancy your committee will evaluate. You believe you can stay objective. What should you do?",
		options: [
			"Stay on the committee because integrity is a personal quality, not a procedure",
			"Inform the chair orally and continue if nobody objects",
			"Disclose the interest in writing and recuse from the evaluation",
			"Vote but abstain from discussion"
		],
		correctIndex: 2,
		explanation: "Conflict of interest is about the appearance and the structure of influence, not your self-assessment. Written disclosure and recusal are the standard. Oral informality is not a defence later.",
		topicTag: "Conflict of interest",
		difficulty: "foundation"
	},
	{
		id: "eth-3",
		competencyId: "ethics",
		stem: "Which statement best captures the difference between a code of conduct and a code of ethics for civil servants?",
		options: [
			"Conduct is optional guidance; ethics is legally enforceable criminal law",
			"Conduct lists prohibited acts; ethics guides judgement when rules run out",
			"They are two names for the same CCS (Conduct) Rules",
			"Ethics applies only to All India Services; conduct applies to Group C"
		],
		correctIndex: 1,
		explanation: "Conduct rules are the floor of prohibited behaviour. Ethics is the competency of choosing well when two duties, or a duty and an instruction, collide. Both apply across the service.",
		topicTag: "Ethics vs conduct",
		difficulty: "practitioner"
	},
	{
		id: "eth-4",
		competencyId: "ethics",
		stem: "A senior asks you to ‘find a way’ around a tender threshold because a conference is in ten days. The legal urgency clause does not fit. Your noting should:",
		options: [
			"Obey first and regularise later, which is standard secretariat practice",
			"Stay silent in the note and raise it privately after the event",
			"Record the rule, the risk, a lawful alternative, and seek written instruction",
			"Leak the matter so that the senior withdraws the request"
		],
		correctIndex: 2,
		explanation: "The file is where institutions protect themselves. Record the legal position, offer a lawful path, and ask for written instruction if pressed. Silence and leaks both fail the office.",
		topicTag: "Unlawful oral instructions",
		difficulty: "practitioner"
	},
	{
		id: "eth-5",
		competencyId: "ethics",
		stem: "Which design change most reliably reduces petty corruption at a certificate counter?",
		options: [
			"A motivational poster on Sevottam behind the clerk",
			"Published time norms, a visible queue, dual control on payments, and a grievance path that does not return to the same desk",
			"Rotating clerks every two days without changing the process",
			"Raising the fee so that only serious applicants come"
		],
		correctIndex: 1,
		explanation: "Petty corruption lives in opaque discretion. Time norms, visibility, dual control, and independent grievance change the process. Posters and rotation without process change do not.",
		topicTag: "Vigilance by design",
		difficulty: "advanced"
	},
	{
		id: "led-1",
		competencyId: "leadership",
		stem: "You inherit a section that files false progress in the weekly review. What is the most effective first move?",
		options: [
			"Publicly reprimand the entire section in the next review",
			"Ignore it until you have been in the chair for six months",
			"Pick one indicator, verify it in the field, and reset the review around evidence rather than rank",
			"Ask each person to submit a personal integrity pledge"
		],
		correctIndex: 2,
		explanation: "False reporting is usually a response to ranking theatre. Change the review: verify one number, reward truth-telling, and inspect bottlenecks. Pledges and public humiliation deepen the hiding.",
		topicTag: "Review culture",
		difficulty: "practitioner"
	},
	{
		id: "led-2",
		competencyId: "leadership",
		stem: "Delegation in a government office is done well when the subordinate receives:",
		options: [
			"The file with a remark ‘please put up a draft’ and no problem statement",
			"Purpose, constraints, decision rights, and the date a decision is needed",
			"Only the correspondence, so they can ‘take a view independently’",
			"Verbal instructions in the corridor, to keep the file clean"
		],
		correctIndex: 1,
		explanation: "Delegation without purpose and decision rights is dumping. Corridor instructions also break the institutional trail. A proper brief is part of leadership, not a courtesy.",
		topicTag: "Delegation",
		difficulty: "foundation"
	},
	{
		id: "led-3",
		competencyId: "leadership",
		stem: "A flood warning arrives at 9 p.m. with incomplete rainfall data. As the officer in charge, you should:",
		options: [
			"Wait for the full IMD bulletin tomorrow to avoid a wrong call",
			"Name what you know, what you do not, choose the costlier error, and issue a precautionary order with that reasoning on record",
			"Ask every department to ‘be prepared’ without a specific tasking",
			"Leave it to the control room operator because the data is incomplete"
		],
		correctIndex: 1,
		explanation: "Incomplete information is the normal condition of field command. Record the uncertainty, choose whether delay or a false start is costlier, and task people. Vague ‘be prepared’ is not a decision.",
		topicTag: "Deciding under uncertainty",
		difficulty: "practitioner"
	},
	{
		id: "led-4",
		competencyId: "leadership",
		stem: "When should a failure be corrected in private rather than recorded as a written warning?",
		options: [
			"Always — written warnings destroy morale",
			"Never — government runs only on paper",
			"When the failure is skill or a first process miss; integrity and repeated concealment belong on the file",
			"Whenever the officer is from your own service"
		],
		correctIndex: 2,
		explanation: "Skill gaps deserve coaching. Integrity failures and concealment need a record. Treating everything as a memo, or nothing as a memo, both damage the organisation.",
		topicTag: "Accountability",
		difficulty: "foundation"
	},
	{
		id: "led-5",
		competencyId: "leadership",
		stem: "An after-action review is most useful when it:",
		options: [
			"Assigns a percentage of blame to each officer",
			"Is postponed until a formal commission writes a report",
			"Is a short, blameless comparison of expected versus actual, with one change to standing orders",
			"Is conducted only if the event made the newspapers"
		],
		correctIndex: 2,
		explanation: "Learning requires speed and psychological safety. A one-page expected-versus-actual with a change to standing orders beats a delayed blame exercise.",
		topicTag: "After-action review",
		difficulty: "advanced"
	},
	{
		id: "cit-1",
		competencyId: "citizen",
		stem: "A citizen charter works when it has:",
		options: [
			"A well-designed poster in the waiting hall",
			"Published time norms, a named owner for each service, and a redress path that does not return to the same desk",
			"A bilingual slogan approved by the ministry",
			"A QR code linking to the department’s Twitter/X account"
		],
		correctIndex: 1,
		explanation: "Charters fail as posters. They work as operational contracts: time, owner, independent redress. Social media is not a substitute for a service-level path.",
		topicTag: "Citizen charter",
		difficulty: "foundation"
	},
	{
		id: "cit-2",
		competencyId: "citizen",
		stem: "Five citizens file the same grievance about a delayed certificate. The officer in charge should treat this as:",
		options: [
			"Five tickets to be closed individually as ‘disposed’",
			"A process bug: inspect the bottleneck and fix the service, then reply to each person with a real next step",
			"Evidence that citizens are being coached by a local politician",
			"A reason to raise the fee and reduce demand"
		],
		correctIndex: 1,
		explanation: "Repeated grievances are a sensor. Closing tickets as ‘disposed’ hides the bug. Fix the process and answer with a concrete next step.",
		topicTag: "Grievance as sensor",
		difficulty: "practitioner"
	},
	{
		id: "cit-3",
		competencyId: "citizen",
		stem: "DBT and Aadhaar seeding reduced leakage in a scheme, but field visits show eligible people without authentication. What is the officer’s duty?",
		options: [
			"Treat exclusion as an acceptable cost of leakage control",
			"Keep a time-bound, logged exception path with human review, and watch both error types",
			"Disable DBT and return to cash through middlemen",
			"Ask beneficiaries to buy better phones"
		],
		correctIndex: 1,
		explanation: "Leakage and exclusion are both failures. An offline, time-bound exception path with a public register is how you keep integrity without disappearing genuine citizens.",
		topicTag: "Inclusion errors",
		difficulty: "practitioner"
	},
	{
		id: "cit-4",
		competencyId: "citizen",
		stem: "Which of the following is a design choice that quietly excludes daily-wage workers?",
		options: [
			"A counter that is open only from 10:30 to 13:00 on weekdays",
			"A form available in the State’s official language",
			"An SMS when the certificate is ready",
			"A token system that shows queue position"
		],
		correctIndex: 0,
		explanation: "Hours that assume a salaried day off are a design choice. Language, SMS, and visible queues usually improve access.",
		topicTag: "Access by design",
		difficulty: "foundation"
	},
	{
		id: "cit-5",
		competencyId: "citizen",
		stem: "Frontline staff (clerks, ANMs, gram rozgar sevak) should be trained as if they were:",
		options: [
			"Temporary contractors whose manner does not represent the State",
			"The policy, because they are the face and the last decision the citizen actually meets",
			"A communications problem to be solved with a new logo",
			"Accountable only to their union, not to service standards"
		],
		correctIndex: 1,
		explanation: "A rude or confused frontline worker can undo a well-written scheme in a minute. Training and standards for them are policy implementation, not a soft extra.",
		topicTag: "Frontline as policy",
		difficulty: "advanced"
	},
	{
		id: "com-1",
		competencyId: "communication",
		stem: "The first paragraph of a note for a Minister should contain:",
		options: [
			"A history of the department since Independence",
			"The decision required, the recommendation, and the core constraint (law, money, or time)",
			"Courtesy and a list of annexes",
			"A full extract of every State’s comments"
		],
		correctIndex: 1,
		explanation: "Seniors decide under time. Lead with the ask, the advice, and the binding constraint. History and annexes follow.",
		topicTag: "Ministerial briefing",
		difficulty: "foundation"
	},
	{
		id: "com-2",
		competencyId: "communication",
		stem: "During a field incident, the authorised public line should prioritise:",
		options: [
			"Cause, blame, and a political contrast",
			"Facts confirmed, next operational steps, and concern for those affected — no speculation on cause",
			"A complete technical briefing including unverified casualty numbers",
			"Silence until a Cabinet note is cleared"
		],
		correctIndex: 1,
		explanation: "Facts, next steps, and sympathy. Speculation on cause, unverified numbers, and blame all create harm. Total silence can also create a vacuum of rumour.",
		topicTag: "Incident communication",
		difficulty: "practitioner"
	},
	{
		id: "com-3",
		competencyId: "communication",
		stem: "A senior gives an oral instruction you believe is unlawful. The professional response is:",
		options: [
			"Carry it out and keep the file clean",
			"Refuse loudly in the meeting so that others witness it",
			"Record the legal objection and a lawful alternative on the file, and ask that the instruction be given in writing",
			"Ignore it and hope it is forgotten"
		],
		correctIndex: 2,
		explanation: "Disagree on paper, with a path. Written confirmation of oral instructions is a classic protection for both the officer and the institution.",
		topicTag: "Disagreeing upwards",
		difficulty: "practitioner"
	},
	{
		id: "com-4",
		competencyId: "communication",
		stem: "Why should you steel-man the opposing view in a briefing note?",
		options: [
			"To lengthen the note so that it looks thorough",
			"Because if you cannot state the strongest case against your advice, you are not ready to advise",
			"It is required by the Manual of Office Procedure in every noting",
			"To please the ministry that disagrees with you"
		],
		correctIndex: 1,
		explanation: "A briefing that cannot state the other side will fail in the room. Steel-manning is quality control for your own recommendation.",
		topicTag: "Steel-manning",
		difficulty: "advanced"
	},
	{
		id: "com-5",
		competencyId: "communication",
		stem: "An official social media forward from a government handle is best treated as:",
		options: [
			"Personal speech, because the platform is private",
			"An official act, and therefore something that should survive the same test as a file noting",
			"Safe if it is only a reshare without comment",
			"Outside Conduct Rules because it is not a gazette notification"
		],
		correctIndex: 1,
		explanation: "The handle is the office. Reshares are still official acts. If it would not belong on a file, it does not belong on the timeline.",
		topicTag: "Official social media",
		difficulty: "foundation"
	},
	{
		id: "not-1",
		competencyId: "noting",
		stem: "A proper noting on a decision file should mainly provide:",
		options: [
			"A chronological restatement of every letter on the correspondence",
			"Facts, the applicable rule, options, and a recommendation the next officer can act on",
			"The phrase ‘submitted for kind orders’ with no options",
			"Personal impressions of the applicant’s tone"
		],
		correctIndex: 1,
		explanation: "Noting is decision support. A restatement of correspondence, or a shrug of ‘kind orders’, forces the next officer to redo the work.",
		topicTag: "Purpose of noting",
		difficulty: "foundation"
	},
	{
		id: "not-2",
		competencyId: "noting",
		stem: "Which instrument is designed to communicate a decision or instruction inside government, typically without creating a new statute?",
		options: [
			"A Gazette notification of an Act of Parliament",
			"An Office Memorandum",
			"A decree nisi",
			"A charge sheet"
		],
		correctIndex: 1,
		explanation: "An OM is the workhorse of intra-government communication of decisions and instructions. It is not itself an Act, a court order, or a criminal process.",
		topicTag: "Instruments",
		difficulty: "foundation"
	},
	{
		id: "not-3",
		competencyId: "noting",
		stem: "‘May kindly see’ as the only operative line of a noting is a problem because:",
		options: [
			"It is grammatically incorrect in British English",
			"It transfers no analysis and asks a senior to reconstruct the decision from raw paper",
			"The Manual forbids the word ‘kindly’",
			"It is too informal for e-Office metadata"
		],
		correctIndex: 1,
		explanation: "The phrase is a ritual shrug. Seniors should receive a recommendation, not a pile.",
		topicTag: "Empty noting",
		difficulty: "practitioner"
	},
	{
		id: "not-4",
		competencyId: "noting",
		stem: "A decision was taken in a meeting and not recorded on the file the same day. The institutional risk is:",
		options: [
			"None, because meetings are more authentic than files",
			"The successor, the auditor, and an RTI applicant will not find the reasons, and oral memory will conflict",
			"Only a delay in printing the minutes",
			"e-Office will auto-generate the noting from the calendar invite"
		],
		correctIndex: 1,
		explanation: "Files are institutional memory. Oral decisions that never land on the file become disputes, audit paras, and unexplainable acts.",
		topicTag: "Recording oral decisions",
		difficulty: "practitioner"
	},
	{
		id: "not-5",
		competencyId: "noting",
		stem: "In a Cabinet note, which of the following is a serious defect?",
		options: [
			"Using the Cabinet Secretariat’s prescribed headings",
			"Burying a large financial implication in an annex while the summary says ‘nil’",
			"Recording a dissenting comment from the Ministry of Law",
			"Stating the decision sought in one paragraph"
		],
		correctIndex: 1,
		explanation: "Hiding money or legal risk is how items unravel in the room or in implementation. Dissent and a clear decision-sought paragraph are features, not defects.",
		topicTag: "Cabinet notes",
		difficulty: "advanced"
	},
	{
		id: "fin-1",
		competencyId: "finance",
		stem: "The GFR standard that ‘expenditure should not be prima facie more than the occasion demands’ is mainly a rule of:",
		options: [
			"Political messaging",
			"Financial propriety, binding the officer who incurs or authorises the spend",
			"Only capital budgets above ₹50 crore",
			"External aid projects"
		],
		correctIndex: 1,
		explanation: "Propriety is personal to the officer who signs. It is not a slogan and not limited to large capital projects.",
		topicTag: "Financial propriety",
		difficulty: "foundation"
	},
	{
		id: "fin-2",
		competencyId: "finance",
		stem: "March rush procurement to ‘use the budget’ is a problem because:",
		options: [
			"Vendors dislike working in March",
			"It typically buys what the calendar demands rather than what the public need demands, and attracts audit",
			"GFR bans all March payments",
			"GeM is closed in March"
		],
		correctIndex: 1,
		explanation: "Year-end dumping is a classic propriety and value-for-money failure. Plan earlier; surrender what you will not spend.",
		topicTag: "Year-end spending",
		difficulty: "foundation"
	},
	{
		id: "fin-3",
		competencyId: "finance",
		stem: "A proprietary article certificate (PAC) should be used when:",
		options: [
			"A brand is familiar to the indenting officer",
			"You can show why a standard equivalent will not meet a documented need, after considering the market",
			"The conference is next week and PAC is faster than a bid",
			"The vendor offers a discount for a PAC route"
		],
		correctIndex: 1,
		explanation: "PAC is an exception with reasons. Familiarity, haste, and discounts are not the legal test.",
		topicTag: "PAC / single source",
		difficulty: "practitioner"
	},
	{
		id: "fin-4",
		competencyId: "finance",
		stem: "The most professional reply to an audit para is:",
		options: [
			"A letter explaining the officers’ good intentions",
			"Documents, the rule, and either a correction of the control or a demonstration that the objection is wrong",
			"A request to drop the para because the amount is small",
			"Silence until the next inspection"
		],
		correctIndex: 1,
		explanation: "Audit asks about the trail. Intentions and smallness do not answer. Fix the control or rebut with paper.",
		topicTag: "Audit paras",
		difficulty: "practitioner"
	},
	{
		id: "fin-5",
		competencyId: "finance",
		stem: "Post-tender negotiation with the L1 bidder, where the rules do not expressly allow it, is risky because:",
		options: [
			"It always increases the price",
			"It turns a competitive, published process into a private conversation and undermines fairness",
			"L1 is never allowed to supply",
			"GeM automatically voids the bid if you talk to the vendor"
		],
		correctIndex: 1,
		explanation: "Fairness lives in the published process. Side conversations after opening are how capture returns.",
		topicTag: "Bid integrity",
		difficulty: "advanced"
	},
	{
		id: "dig-1",
		competencyId: "digital",
		stem: "Digital Public Infrastructure is best described as:",
		options: [
			"A new ministry portal for every scheme",
			"Shared rails (identity, payments, consented data) that many services can ride",
			"Free smartphones for all officials",
			"A social media unit in the PIB"
		],
		correctIndex: 1,
		explanation: "DPI is rails, not a stack of unmaintained portals. Officers should ask whether a service can ride existing rails.",
		topicTag: "DPI concept",
		difficulty: "foundation"
	},
	{
		id: "dig-2",
		competencyId: "digital",
		stem: "A well-designed digital service still needs an offline path because:",
		options: [
			"The IT Act requires paper",
			"Authentication failures, connectivity, disability, and literacy otherwise become exclusion",
			"Portals cannot legally issue certificates",
			"States are not allowed on Central systems"
		],
		correctIndex: 1,
		explanation: "Exclusion is the twin of digitisation. A human, time-bound exception path is part of the service, not a defeat.",
		topicTag: "Offline inclusion",
		difficulty: "practitioner"
	},
	{
		id: "dig-3",
		competencyId: "digital",
		stem: "Putting a citizen’s personal file into a public generative-AI chat is wrong primarily because:",
		options: [
			"The model will refuse to answer",
			"You may disclose personal or unreleased official information to a system outside your control, with no duty of care",
			"Hindi prompts are not supported",
			"It violates the Manual of Office Procedure’s typewriter clause"
		],
		correctIndex: 1,
		explanation: "Public models are not your file room. Personal data and unreleased notes do not belong there. You remain accountable.",
		topicTag: "AI and official data",
		difficulty: "foundation"
	},
	{
		id: "dig-4",
		competencyId: "digital",
		stem: "e-Office is used well when officers:",
		options: [
			"Print every noting to read it ‘properly’",
			"Use receipts, reminders, and the audit trail, and record oral decisions on the digital file the same day",
			"Keep a parallel paper file as the real record",
			"Put the entire correspondence in a single unsearchable PDF named ‘final’"
		],
		correctIndex: 1,
		explanation: "Digitising paper habits (print, parallel files, unsearchable dumps) wastes the tool. Receipts and same-day recording are the point.",
		topicTag: "e-Office discipline",
		difficulty: "practitioner"
	},
	{
		id: "dig-5",
		competencyId: "digital",
		stem: "Under a data-protection mindset, the default for a clerk’s screen showing Aadhaar and bank details should be:",
		options: [
			"Full numbers, so that verification is faster",
			"Masked fields, role-based access, and a log of who viewed what",
			"A shared login for the whole section",
			"Screenshots stored on personal WhatsApp for ‘backup’"
		],
		correctIndex: 1,
		explanation: "Collect less, mask by default, log access. Shared logins and WhatsApp backups are how leaks happen.",
		topicTag: "Data protection",
		difficulty: "advanced"
	},
	{
		id: "dat-1",
		competencyId: "data",
		stem: "A vanity metric in a government programme is typically:",
		options: [
			"A field-verifiable quality measure",
			"An output that looks like success (houses tagged, people trained) without a quality or outcome check",
			"Any number reported to NITI Aayog",
			"A sample survey"
		],
		correctIndex: 1,
		explanation: "Outputs without quality are how reviews are gamed. Pair them with a check that would survive a Thursday field visit.",
		topicTag: "Vanity metrics",
		difficulty: "foundation"
	},
	{
		id: "dat-2",
		competencyId: "data",
		stem: "90% coverage of ‘registered’ names is not the same as 90% of the eligible because:",
		options: [
			"Percentages are banned in official reports",
			"The denominator may omit people who never entered the list",
			"Registration is always larger than eligibility",
			"Eligible people are defined only after Census 2027"
		],
		correctIndex: 1,
		explanation: "Always ask who is missing from the list you are using. Registration is not the universe of the eligible.",
		topicTag: "Denominators",
		difficulty: "practitioner"
	},
	{
		id: "dat-3",
		competencyId: "data",
		stem: "When MIS, a sample, and a field walk disagree, a careful officer should:",
		options: [
			"Use only the MIS because it is official",
			"Triangulate, publish caveats, and treat a ranged truth as better than a precise falsehood",
			"Average the three numbers",
			"Suppress the field walk as anecdotal"
		],
		correctIndex: 1,
		explanation: "Dirty data is normal. Triangulation and caveats are honesty. Official status does not make a number true.",
		topicTag: "Triangulation",
		difficulty: "practitioner"
	},
	{
		id: "dat-4",
		competencyId: "data",
		stem: "Ranking districts every month on a large basket of indicators often produces:",
		options: [
			"Pure learning about what works",
			"Gaming, false reporting, and less attention to the few indicators that actually move lives",
			"Automatic extra central funds",
			"A legally required CAG format"
		],
		correctIndex: 1,
		explanation: "Rank theatre drives gaming. Review change on a small set, and spend time on exceptions.",
		topicTag: "Review design",
		difficulty: "advanced"
	},
	{
		id: "dat-5",
		competencyId: "data",
		stem: "Geo-tagging a completed work is most useful when it is paired with:",
		options: [
			"A quality check that the asset exists and functions",
			"A press release the same day",
			"A unique colour on the dashboard",
			"A requirement that the photo include the officer"
		],
		correctIndex: 0,
		explanation: "A pin on a map can be a photo of a wall. Functioning is the outcome. Officer selfies are not a control.",
		topicTag: "Asset verification",
		difficulty: "foundation"
	},
	{
		id: "pol-1",
		competencyId: "policy",
		stem: "The first task in policy design is:",
		options: [
			"To name the scheme so that it can be announced",
			"To diagnose the problem precisely enough that the instrument could be wrong if the diagnosis is wrong",
			"To copy a neighbouring State’s notification",
			"To prepare the logo and the hashtag"
		],
		correctIndex: 1,
		explanation: "A scheme is not a diagnosis. Price, water, credit, and market access imply different tools. Naming first is how last year’s scheme returns with a new title.",
		topicTag: "Problem diagnosis",
		difficulty: "foundation"
	},
	{
		id: "pol-2",
		competencyId: "policy",
		stem: "A ban without enforcement capacity typically becomes:",
		options: [
			"An immediate cultural change",
			"A rent for those who can still do the banned thing quietly",
			"A self-executing regulation",
			"A substitute for a budget"
		],
		correctIndex: 1,
		explanation: "Unenforced bans create informal markets and rents. Instrument choice must include who will actually implement.",
		topicTag: "Instrument choice",
		difficulty: "practitioner"
	},
	{
		id: "pol-3",
		competencyId: "policy",
		stem: "A subsidy without an exit or review date tends to become:",
		options: [
			"A one-time stimulus as designed",
			"An entitlement that is politically and fiscally hard to retarget",
			"Automatically targeted by Aadhaar",
			"Illegal after one financial year"
		],
		correctIndex: 1,
		explanation: "Write the kill or retarget criterion on day one. Administrative and political capacity are finite.",
		topicTag: "Subsidies",
		difficulty: "practitioner"
	},
	{
		id: "pol-4",
		competencyId: "policy",
		stem: "Why should a new Central scheme name the State’s implementation load in the proposal?",
		options: [
			"Courtesy to Chief Secretaries",
			"Because a notification the block cannot run is literature, not policy",
			"The Seventh Schedule always makes the Centre the implementer",
			"NITI Aayog forbids schemes that mention States"
		],
		correctIndex: 1,
		explanation: "Implementation architecture — who, money, date, metric — belongs in the proposal. Federal courtesy is not the point; deliverability is.",
		topicTag: "Implementation architecture",
		difficulty: "advanced"
	},
	{
		id: "pol-5",
		competencyId: "policy",
		stem: "Adding a scheme without retiring another is a problem mainly because:",
		options: [
			"The Gazette has a page limit",
			"District and block capacity is finite; extra schemes become unread circulars",
			"Finance Ministry bans any two schemes in the same sector",
			"Citizens can only remember one scheme name"
		],
		correctIndex: 1,
		explanation: "Capacity, not branding, is the constraint. Sunset and kill criteria protect the offices that must deliver.",
		topicTag: "Administrative capacity",
		difficulty: "foundation"
	},
	{
		id: "dis-1",
		competencyId: "disaster",
		stem: "At district level, the Disaster Management Act typically places coordination in the:",
		options: [
			"NITI Aayog cell",
			"District Disaster Management Authority, usually chaired by the Collector",
			"Municipal standing committee alone, even in rural areas",
			"Press Information Bureau"
		],
		correctIndex: 1,
		explanation: "DDMA is the legal home of district preparedness and response. It is not a ceremonial board.",
		topicTag: "DM Act roles",
		difficulty: "foundation"
	},
	{
		id: "dis-2",
		competencyId: "disaster",
		stem: "In the first 72 hours of a sudden disaster, the operational priority is:",
		options: [
			"A detailed reconstruction policy",
			"People (rescue, medical, water), then access, then a single information channel",
			"A full inquiry into cause",
			"Updating the district website theme"
		],
		correctIndex: 1,
		explanation: "Rescue and life support beat optics and inquiries. One command and one spokesperson reduce chaos.",
		topicTag: "First 72 hours",
		difficulty: "practitioner"
	},
	{
		id: "dis-3",
		competencyId: "disaster",
		stem: "Why name women, persons with disability, and migrants in the first relief order?",
		options: [
			"It is required only for World Bank funded projects",
			"If they are not named, camps and lists tend to render them invisible",
			"They are the only groups eligible for relief",
			"To satisfy a separate ministry’s dashboard"
		],
		correctIndex: 1,
		explanation: "Inclusion is operational. Unnamed groups do not appear in the first camp, the first list, or the first medical desk.",
		topicTag: "Inclusive relief",
		difficulty: "practitioner"
	},
	{
		id: "dis-4",
		competencyId: "disaster",
		stem: "Using published relief standards rather than inventing amounts under cameras is important because:",
		options: [
			"It keeps fairness defensible and reduces arbitrary, photogenic exceptions",
			"Standards are only for drought, not floods",
			"Cameras automatically audit the amounts",
			"NDMA forbids any exception ever"
		],
		correctIndex: 0,
		explanation: "Standards are how you stay fair when the room is loud. Exceptions can exist — they should be documented, not invented for the shot.",
		topicTag: "Relief standards",
		difficulty: "foundation"
	},
	{
		id: "dis-5",
		competencyId: "disaster",
		stem: "‘Build back better’ after a disaster primarily means:",
		options: [
			"Spending the entire SDRF in 30 days",
			"Replacing the lost asset with one that is safer or less exposed, not only faster to inaugurate",
			"Using a new contractor as a matter of principle",
			"Moving the district HQ to the capital"
		],
		correctIndex: 1,
		explanation: "Speed without safety repeats the disaster. Reconstruction is a risk-reduction moment.",
		topicTag: "Reconstruction",
		difficulty: "advanced"
	},
	{
		id: "urb-1",
		competencyId: "urban",
		stem: "A municipal body’s autonomy is most visible in:",
		options: [
			"The number of Central schemes it can list on a hoarding",
			"Own-source revenue (property tax, user charges) that is assessed and collected, not only budgeted",
			"A smart-city command centre",
			"The Mayor’s social media following"
		],
		correctIndex: 1,
		explanation: "Grants without own-source revenue make the city a pass-through. Assessment and collection are governance.",
		topicTag: "Municipal finance",
		difficulty: "foundation"
	},
	{
		id: "urb-2",
		competencyId: "urban",
		stem: "Publishing a property-tax arrears list is mainly a tool to:",
		options: [
			"Shame the poor",
			"Reduce the darkness in which influential defaulters hide",
			"Replace GIS assessment",
			"Satisfy a census requirement"
		],
		correctIndex: 1,
		explanation: "Arrears opacity is a subsidy to the powerful. Publication is a fairness tool when assessment is also fair.",
		topicTag: "Tax arrears",
		difficulty: "practitioner"
	},
	{
		id: "urb-3",
		competencyId: "urban",
		stem: "A ‘smart’ dashboard that does not change when a waste truck misses a ward is:",
		options: [
			"Still useful as a brand asset",
			"Decoration; service levels need named owners at ward level",
			"Required before hiring sanitary workers",
			"A substitute for user charges"
		],
		correctIndex: 1,
		explanation: "If the truck does not move, the dashboard is not operations. Ward-level service levels with owners are the contract.",
		topicTag: "Urban services",
		difficulty: "practitioner"
	},
	{
		id: "urb-4",
		competencyId: "urban",
		stem: "Convergence of rural schemes at habitation level is primarily:",
		options: [
			"A workshop and a memorandum of understanding",
			"A map-and-calendar problem: the same list of habitations until the lists match",
			"The job of a new mission directorate in the State capital",
			"Impossible because each scheme has its own MIS"
		],
		correctIndex: 1,
		explanation: "Workshops do not converge. Matching lists and calendars do. MIS silos are a reason to sit together, not a reason to give up.",
		topicTag: "Scheme convergence",
		difficulty: "advanced"
	},
	{
		id: "urb-5",
		competencyId: "urban",
		stem: "Gram sabha, in law, is:",
		options: [
			"A photo opportunity at the start of a visit",
			"The forum of all registered voters of the panchayat, with a role in priority-setting and social audit",
			"An advisory NGO",
			"A committee nominated by the BDO"
		],
		correctIndex: 1,
		explanation: "Gram sabha is a legal forum, not a backdrop. Using it is part of rural governance, not an optional courtesy.",
		topicTag: "Panchayati raj",
		difficulty: "foundation"
	},
	{
		id: "law-1",
		competencyId: "law",
		stem: "BNS, BNSS, and BSA replaced which trio?",
		options: [
			"CPC, Contract Act, and Transfer of Property Act",
			"IPC, CrPC, and the Indian Evidence Act",
			"Police Act, DM Act, and Arms Act",
			"IT Act, DPDP Act, and Telegraph Act"
		],
		correctIndex: 1,
		explanation: "The new criminal codes replace the IPC, CrPC, and Evidence Act. Keep a conversion table at the desk until the new numbers are muscle memory.",
		topicTag: "New codes map",
		difficulty: "foundation"
	},
	{
		id: "law-2",
		competencyId: "law",
		stem: "The coming of new criminal codes means that due process:",
		options: [
			"Has been repealed for cognizable offences",
			"Still requires legal grounds for arrest, a record of search and seizure, and proper investigation — reform is not a shortcut",
			"Now allows confessions to police as the primary evidence in all cases",
			"Applies only in metropolitan areas"
		],
		correctIndex: 1,
		explanation: "Reform of the map is not a free hand. Lost procedure still loses the case and the public.",
		topicTag: "Due process",
		difficulty: "practitioner"
	},
	{
		id: "law-3",
		competencyId: "law",
		stem: "A district officer asked to ‘concur’ in a criminal-process note should:",
		options: [
			"Concur because criminal process is only the SP’s business",
			"Read the working map — cognizability, victim-process, timelines — before signing",
			"Rewrite the FIR in her own words",
			"Wait for a Supreme Court handbook in Hindi only"
		],
		correctIndex: 1,
		explanation: "Non-police officers still bind the system when they concur. Ignorance of the new map is not a defence.",
		topicTag: "Non-police duties",
		difficulty: "practitioner"
	},
	{
		id: "law-4",
		competencyId: "law",
		stem: "Why keep a section conversion table at the police station or magistrate’s desk during transition?",
		options: [
			"It is a CVC requirement for procurement files",
			"Muscle memory of old numbers will otherwise produce wrong charges, wrong process, and failed cases",
			"New codes cannot be applied without the table as a legal instrument",
			"It replaces the need for training"
		],
		correctIndex: 1,
		explanation: "Transition errors are operational, not theoretical. Training plus a desk table is how you avoid charging the wrong section.",
		topicTag: "Transition discipline",
		difficulty: "foundation"
	},
	{
		id: "law-5",
		competencyId: "law",
		stem: "Electronic processes in the new codes are best treated as:",
		options: [
			"A reason to skip contemporaneous records",
			"Tools that still need a reliable trail — timestamps, hashes, and human certification where required",
			"Valid only if printed and signed in wet ink the same hour",
			"Optional for organised crime, mandatory for petty cases"
		],
		correctIndex: 1,
		explanation: "Electronic is not the same as untraceable. The trail still has to stand in court.",
		topicTag: "Electronic process",
		difficulty: "advanced"
	}
];
function questionsFor(competencyId, difficulty) {
	return QUESTION_BANK.filter((q) => q.competencyId === competencyId && (difficulty ? q.difficulty === difficulty : true));
}
function shuffle(items) {
	const copy = [...items];
	for (let i = copy.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[copy[i], copy[j]] = [copy[j], copy[i]];
	}
	return copy;
}
function buildBankQuiz(input) {
	const pool = questionsFor(input.competencyId);
	if (pool.length === 0) return null;
	const preferred = input.difficulty ? pool.filter((q) => q.difficulty === input.difficulty) : pool;
	const picked = shuffle(preferred.length >= 4 ? preferred : pool).slice(0, input.count ?? 6);
	const competency = COMPETENCIES.find((c) => c.id === input.competencyId);
	return {
		id: crypto.randomUUID(),
		title: input.title ?? `${competency?.name ?? "Competency"} diagnostic`,
		competencyId: input.competencyId,
		source: "bank",
		questions: picked,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function buildRoleQuiz(profile) {
	const role = roleById(profile.roleId);
	const ids = profile.workFocus.length > 0 ? profile.workFocus : role?.competencyIds ?? COMPETENCIES.slice(0, 4).map((c) => c.id);
	const picked = [];
	for (const id of ids) {
		const fromComp = shuffle(questionsFor(id)).slice(0, 2);
		picked.push(...fromComp);
		if (picked.length >= 8) break;
	}
	if (picked.length < 8) {
		const used = new Set(picked.map((q) => q.id));
		const extra = shuffle(QUESTION_BANK.filter((q) => !used.has(q.id)));
		picked.push(...extra.slice(0, 8 - picked.length));
	}
	return {
		id: crypto.randomUUID(),
		title: `Role diagnostic · ${role?.name ?? "Official"}`,
		competencyId: ids[0] ?? "ethics",
		source: "bank",
		questions: picked.slice(0, 8),
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function scoreAttempt(questions, answers) {
	let correct = 0;
	const weak = [];
	questions.forEach((q, i) => {
		if (answers[i] === q.correctIndex) correct += 1;
		else weak.push(q.topicTag);
	});
	const unique = [...new Set(weak)];
	return {
		correct,
		score: questions.length ? Math.round(correct / questions.length * 100) : 0,
		weakTopics: unique
	};
}
function parseQuizPayload(raw, competencyId) {
	const trimmed = raw.trim();
	const candidate = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/)?.[1]?.trim() ?? trimmed;
	const start = candidate.indexOf("{");
	const end = candidate.lastIndexOf("}");
	if (start < 0 || end <= start) return null;
	try {
		const json = JSON.parse(candidate.slice(start, end + 1));
		if (!Array.isArray(json.questions) || json.questions.length < 4) return null;
		const questions = [];
		for (const [i, q] of json.questions.slice(0, 8).entries()) {
			const options = (q.options ?? []).map((o) => String(o)).filter(Boolean);
			if (!q.stem || options.length < 4) continue;
			const correct = Number(q.correctIndex);
			if (!Number.isInteger(correct) || correct < 0 || correct > 3) continue;
			const diff = q.difficulty;
			const difficulty = diff === "advanced" || diff === "practitioner" ? diff : "foundation";
			questions.push({
				id: `ai-${crypto.randomUUID()}-${i}`,
				competencyId,
				stem: String(q.stem),
				options: [
					options[0],
					options[1],
					options[2],
					options[3]
				],
				correctIndex: correct,
				explanation: String(q.explanation ?? "Review the related circular and rule."),
				topicTag: String(q.topicTag ?? "Applied judgement"),
				difficulty
			});
		}
		if (questions.length < 4) return null;
		return {
			id: crypto.randomUUID(),
			title: json.title?.trim() || "Custom diagnostic",
			competencyId,
			source: "ai",
			questions,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
	} catch {
		return null;
	}
}
//#endregion
export { scoreAttempt as i, buildRoleQuiz as n, parseQuizPayload as r, buildBankQuiz as t };
