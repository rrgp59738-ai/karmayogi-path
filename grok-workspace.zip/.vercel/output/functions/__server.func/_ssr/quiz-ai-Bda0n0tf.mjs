import { n as COMPETENCIES } from "./catalog-7qHhzf7T.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { r as parseQuizPayload } from "./quiz-engine-DNPRNqzs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz-ai-Bda0n0tf.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var generateAiQuiz_createServerFn_handler = createServerRpc({
	id: "3cf293fe08bc0108cc7a9d13c122613027f8699ca7b86f27129e96ca914a8e0f",
	name: "generateAiQuiz",
	filename: "src/lib/quiz-ai.ts"
}, (opts) => generateAiQuiz.__executeServer(opts));
var generateAiQuiz = createServerFn({ method: "POST" }).validator((input) => input).handler(generateAiQuiz_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI generation is unavailable in this environment."
	};
	const competency = COMPETENCIES.find((c) => c.id === data.competencyId);
	if (!competency) return {
		ok: false,
		error: "Unknown competency."
	};
	const prompt = `You write diagnostic multiple-choice quizzes for Indian government officials on the Karmayogi Path learning platform (inspired by Mission Karmayogi / iGOT, but original — do not copy any copyrighted iGOT course text).

Officer:
- Role: ${data.roleName}
- Designation: ${data.designation || "Not specified"}
- Ministry / department: ${data.ministry || "Not specified"}
- Years of service: ${data.yearsOfService}
- Work focus tags: ${data.workFocus.join(", ") || "none"}

Competency to test: ${competency.name} (${competency.category}). ${competency.blurb}
Difficulty: ${data.difficulty}

Write 8 original MCQs that a working officer would actually get wrong if they were weak in this competency. Ground items in Indian administration: GFR/GeM, noting, citizen service, DM Act, RTI, Conduct Rules, DPI, scheme delivery, new criminal codes (BNS/BNSS/BSA) where relevant. No trick grammar questions. No party politics. No celebrity trivia.

Return ONLY JSON:
{
  "title": string,
  "questions": [
    {
      "stem": string,
      "options": [string, string, string, string],
      "correctIndex": 0 | 1 | 2 | 3,
      "explanation": string (2-3 sentences, teach the rule),
      "topicTag": string (short),
      "difficulty": "foundation" | "practitioner" | "advanced"
    }
  ]
}`;
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .4,
				max_tokens: 2400,
				messages: [{
					role: "user",
					content: prompt
				}]
			})
		});
		if (!res.ok) return {
			ok: false,
			error: `AI service returned ${res.status}. Try the curated diagnostic.`
		};
		const text = (await res.json()).choices?.[0]?.message?.content ?? "";
		const quiz = parseQuizPayload(text, data.competencyId);
		if (!quiz) return {
			ok: false,
			error: "The generated quiz could not be read. Try again or use the curated set."
		};
		return {
			ok: true,
			quiz
		};
	} catch {
		return {
			ok: false,
			error: "Could not reach the AI service. Use the curated diagnostic."
		};
	}
});
//#endregion
export { generateAiQuiz_createServerFn_handler };
