import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as modulesFor, n as COMPETENCIES, r as COURSES, u as roleById } from "./catalog-7qHhzf7T.mjs";
import { c as Compass, m as ArrowRight, r as Target, s as GraduationCap } from "../_libs/lucide-react.mjs";
import { l as proficiency, o as useAppStore, s as useHydrated, u as recommendCourses } from "./router-C5Kd15x_.mjs";
import { t as Badge } from "./badge-CUilnUdH.mjs";
import { t as Button } from "./button-BjATLKEN.mjs";
import { t as CourseCard } from "./course-card-41d8qhbq.mjs";
import { t as Card } from "./card-CJLH9mWJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-tUaof7Nj.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const hydrated = useHydrated();
	const profile = useAppStore((s) => s.profile);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeSkeleton, {});
	if (!profile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landing, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {});
}
function HomeSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse rounded-xl bg-navy/8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-xl bg-navy/6" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-xl bg-navy/6" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-xl bg-navy/6" })
			]
		})]
	});
}
function Landing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-xl bg-navy px-6 py-10 text-primary-foreground md:px-12 md:py-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.22em] text-saffron",
						children: "Mission-ready learning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 max-w-2xl font-display text-4xl font-semibold leading-tight tracking-tight md:text-5xl",
						children: "Find the gap. Learn what the chair actually needs."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-base leading-relaxed text-primary-foreground/75",
						children: "Karmayogi Path is a diagnostic companion for Indian government officials. Sit a short quiz on the competencies of your role, see where the work is thin, and take a course built for that weakness — noting, propriety, citizen service, disaster command, and more."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "saffron",
							size: "lg",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/onboard",
								children: ["Set your role", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "lg",
							className: "border-0 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/16",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/courses",
								children: "Browse courses"
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid gap-4 md:grid-cols-3",
				children: [
					{
						icon: Compass,
						title: "Diagnose",
						body: "A role diagnostic or a custom AI quiz on one competency. Eight questions. No theatre."
					},
					{
						icon: Target,
						title: "See the weakness",
						body: "Topic tags you missed become a map — ethics, GeM, RTI, first 72 hours, denominators."
					},
					{
						icon: GraduationCap,
						title: "Take the course",
						body: "Short original modules in the Mission Karmayogi spirit: behavioural, functional, domain."
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5 text-saffron" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-xl font-semibold text-navy",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: item.body
						})
					]
				}, item.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold text-navy",
					children: "Twelve competencies"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/diagnose",
					className: "text-sm font-medium text-saffron hover:underline",
					children: "Test one"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 md:grid-cols-4",
				children: COMPETENCIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/diagnose",
					search: { competency: c.id },
					className: "rounded-lg bg-paper-raised p-4 shadow-border transition-shadow duration-150 hover:shadow-[var(--shadow-border-hover)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: c.category === "behavioral" ? "Behavioural" : c.category === "functional" ? "Functional" : "Domain" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-lg font-semibold leading-snug text-navy",
							children: c.short
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 line-clamp-2 text-xs text-muted",
							children: c.blurb
						})
					]
				}, c.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-4 font-display text-2xl font-semibold text-navy",
				children: "Start a course"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: COURSES.slice(0, 3).map((course) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseCard, { course }, course.id))
			})] })
		]
	});
}
function Dashboard() {
	const profile = useAppStore((s) => s.profile);
	const scores = useAppStore((s) => s.scores);
	const courseProgress = useAppStore((s) => s.courseProgress);
	const attempts = useAppStore((s) => s.attempts);
	const role = roleById(profile.roleId);
	const recs = recommendCourses(profile, scores, 3);
	const inProgress = Object.values(courseProgress).filter((p) => !p.completedAt);
	const weak = Object.values(scores).filter((s) => s.score < 75).sort((a, b) => a.score - b.score).slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col justify-between gap-6 md:flex-row md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.2em] text-saffron",
						children: [
							role?.cadre,
							" · ",
							profile.ministry
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-2 font-display text-3xl font-semibold tracking-tight text-navy md:text-4xl",
						children: [
							greeting(),
							", ",
							firstName(profile.name)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-muted",
						children: attempts.length === 0 ? "You have not sat a diagnostic yet. Ten minutes will tell you more than a year of untested circulars." : `${attempts.length} diagnostic${attempts.length === 1 ? "" : "s"} on file. The map updates each time you sit one.`
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "saffron",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/diagnose",
						children: ["Sit a diagnostic", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-muted",
						children: "Diagnostics"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl font-semibold tabular-nums text-navy",
						children: attempts.length
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-muted",
						children: "Courses in motion"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl font-semibold tabular-nums text-navy",
						children: inProgress.length
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-muted",
						children: "Thin spots"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl font-semibold tabular-nums text-navy",
						children: weak.length
					})] })
				]
			}),
			weak.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 font-display text-2xl font-semibold text-navy",
				children: "Where the work is thin"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-3",
				children: weak.map((s) => {
					const c = COMPETENCIES.find((x) => x.id === s.competencyId);
					const p = proficiency(s.score);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg font-semibold text-navy",
							children: c?.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: c?.blurb
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							tone: p.tone,
							children: [s.score, "%"]
						})]
					}, s.competencyId);
				})
			})] }),
			inProgress.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 font-display text-2xl font-semibold text-navy",
				children: "Continue"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: inProgress.slice(0, 2).map((p) => {
					const course = COURSES.find((c) => c.id === p.courseId);
					if (!course) return null;
					const total = modulesFor(course.id).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseCard, {
						course,
						progress: {
							completed: p.completedModuleIds.length,
							total
						}
					}, course.id);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold text-navy",
					children: "Recommended for your chair"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/courses",
					className: "text-sm font-medium text-saffron hover:underline",
					children: "All courses"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: recs.map((course) => {
					const p = courseProgress[course.id];
					const total = modulesFor(course.id).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseCard, {
						course,
						progress: p ? {
							completed: p.completedModuleIds.length,
							total,
							done: Boolean(p.completedAt)
						} : void 0
					}, course.id);
				})
			})] })
		]
	});
}
function greeting() {
	const h = (/* @__PURE__ */ new Date()).getHours();
	if (h < 12) return "Good morning";
	if (h < 17) return "Good afternoon";
	return "Good evening";
}
function firstName(name) {
	return name.trim().split(/\s+/)[0] || name;
}
//#endregion
export { Home as component };
