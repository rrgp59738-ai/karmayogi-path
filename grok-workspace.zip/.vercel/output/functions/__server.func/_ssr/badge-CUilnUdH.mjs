import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as cn } from "./router-C5Kd15x_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-CUilnUdH.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, tone = "neutral", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", tone === "neutral" && "bg-navy/8 text-navy", tone === "navy" && "bg-navy text-primary-foreground", tone === "saffron" && "bg-saffron/15 text-saffron", tone === "forest" && "bg-forest/12 text-forest", tone === "weak" && "bg-danger/12 text-danger", tone === "mid" && "bg-warn/15 text-warn", tone === "strong" && "bg-forest/12 text-forest", tone === "untouched" && "bg-ink/6 text-muted", className),
		...props
	});
}
//#endregion
export { Badge as t };
