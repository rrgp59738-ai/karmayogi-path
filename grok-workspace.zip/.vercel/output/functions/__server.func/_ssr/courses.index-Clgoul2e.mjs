import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as modulesFor, r as COURSES, t as CATEGORY_LABEL } from "./catalog-7qHhzf7T.mjs";
import { d as cn, o as useAppStore, s as useHydrated, u as recommendCourses } from "./router-C5Kd15x_.mjs";
import { t as CourseCard } from "./course-card-41d8qhbq.mjs";
import { t as Input } from "./input-D2PE5WSI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courses.index-Clgoul2e.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "behavioral",
		label: "Behavioural"
	},
	{
		id: "functional",
		label: "Functional"
	},
	{
		id: "domain",
		label: "Domain"
	}
];
function CoursesPage() {
	const hydrated = useHydrated();
	const profile = useAppStore((s) => s.profile);
	const scores = useAppStore((s) => s.scores);
	const courseProgress = useAppStore((s) => s.courseProgress);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [q, setQ] = (0, import_react.useState)("");
	const recommended = hydrated ? recommendCourses(profile, scores, 3) : [];
	const list = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return COURSES.filter((c) => {
			if (filter !== "all" && c.category !== filter) return false;
			if (!query) return true;
			return c.title.toLowerCase().includes(query) || c.subtitle.toLowerCase().includes(query) || CATEGORY_LABEL[c.category].toLowerCase().includes(query);
		});
	}, [filter, q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.2em] text-saffron",
						children: "Learn"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl font-semibold text-navy md:text-4xl",
						children: "Courses for the work, not the calendar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "Original competency-building modules in the spirit of Mission Karmayogi — short enough to finish between files, dense enough to change the next noting."
					})
				]
			}),
			hydrated && recommended.length > 0 && profile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 font-display text-2xl font-semibold text-navy",
				children: "For your gaps"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: recommended.map((course) => {
					const p = courseProgress[course.id];
					const total = modulesFor(course.id).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseCard, {
						course,
						featured: true,
						progress: p ? {
							completed: p.completedModuleIds.length,
							total,
							done: Boolean(p.completedAt)
						} : void 0
					}, course.id);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 md:flex-row md:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search courses",
					"aria-label": "Search courses",
					className: "md:max-w-xs"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter(f.id),
						className: cn("h-11 rounded-full px-4 text-sm font-medium shadow-border", filter === f.id ? "bg-navy text-primary-foreground" : "bg-paper-raised text-ink"),
						children: f.label
					}, f.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-2 lg:grid-cols-3",
				children: list.map((course) => {
					const p = courseProgress[course.id];
					const total = modulesFor(course.id).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseCard, {
						course,
						progress: p ? {
							completed: p.completedModuleIds.length,
							total,
							done: Boolean(p.completedAt)
						} : void 0
					}, course.id);
				})
			}),
			list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No course matches that search."
			})
		]
	});
}
//#endregion
export { CoursesPage as component };
