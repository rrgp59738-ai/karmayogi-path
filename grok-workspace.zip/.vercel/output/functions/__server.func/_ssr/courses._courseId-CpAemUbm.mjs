import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as courseById, i as LEVEL_LABEL, l as modulesFor, s as competencyById, t as CATEGORY_LABEL } from "./catalog-7qHhzf7T.mjs";
import { d as Check, l as Clock, u as ChevronLeft } from "../_libs/lucide-react.mjs";
import { c as coursesForCompetency, d as cn, i as Route$2, o as useAppStore, s as useHydrated } from "./router-C5Kd15x_.mjs";
import { t as Badge } from "./badge-CUilnUdH.mjs";
import { t as Button } from "./button-BjATLKEN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courses._courseId-CpAemUbm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CoursePage() {
	const { courseId } = Route$2.useParams();
	const course = courseById(courseId);
	const modules = modulesFor(courseId);
	const hydrated = useHydrated();
	const progress = useAppStore((s) => s.courseProgress[courseId]);
	const startCourse = useAppStore((s) => s.startCourse);
	const completeModule = useAppStore((s) => s.completeModule);
	const [active, setActive] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!hydrated || !course) return;
		startCourse(course.id);
	}, [
		hydrated,
		course,
		startCourse
	]);
	(0, import_react.useEffect)(() => {
		setActive(0);
	}, [courseId]);
	if (!course) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 py-12 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl font-semibold text-navy",
			children: "Course not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/courses",
				children: "Back to courses"
			})
		})]
	});
	const mod = modules[active];
	const completed = new Set(progress?.completedModuleIds ?? []);
	const related = course.competencyIds.flatMap(coursesForCompetency).filter((c) => c.id !== course.id).slice(0, 2);
	function markDone() {
		if (!mod || !course) return;
		completeModule(course.id, mod.id, modules.length);
		if (active < modules.length - 1) setActive((i) => i + 1);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/courses",
				className: "inline-flex items-center gap-1 text-sm font-medium text-muted hover:text-navy",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "All courses"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rounded-xl bg-navy px-6 py-8 text-primary-foreground md:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "bg-primary-foreground/10 text-primary-foreground",
							children: CATEGORY_LABEL[course.category]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "bg-saffron/90 text-saffron-fg",
							children: LEVEL_LABEL[course.level]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 font-display text-3xl font-semibold tracking-tight md:text-4xl",
						children: course.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-primary-foreground/75",
						children: course.subtitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 flex flex-wrap items-center gap-3 text-sm text-primary-foreground/60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" }),
									" ",
									course.durationMin,
									" min"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: course.audience }),
							course.competencyIds.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: competencyById(id)?.name }, id))
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-[220px_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "flex gap-2 overflow-x-auto lg:flex-col lg:overflow-visible",
					children: modules.map((m, i) => {
						const done = completed.has(m.id);
						const on = i === active;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "min-w-[11rem] lg:min-w-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setActive(i),
								className: cn("flex w-full items-start gap-2 rounded-md px-3 py-3 text-left text-sm shadow-border", on ? "bg-navy text-primary-foreground" : "bg-paper-raised"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold", done ? "bg-forest text-primary-foreground" : on ? "bg-saffron text-saffron-fg" : "bg-navy/10 text-navy"),
									children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }) : i + 1
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-medium leading-snug",
									children: m.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: cn("text-xs", on ? "text-primary-foreground/60" : "text-muted"),
									children: [m.minutes, " min"]
								})] })]
							})
						}, m.id);
					})
				}), mod && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-paper-raised p-5 shadow-border md:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold uppercase tracking-[0.18em] text-saffron",
							children: ["Module ", active + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-2xl font-semibold text-navy",
							children: mod.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 space-y-4 text-[1.05rem] leading-relaxed text-ink",
							children: mod.paragraphs.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: p }, p.slice(0, 24)))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 rounded-lg bg-navy/5 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-wider text-muted",
								children: "Takeaways"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 space-y-2",
								children: mod.takeaways.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-2 text-sm leading-snug text-navy",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-forest" }), t]
								}, t))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								disabled: active === 0,
								onClick: () => setActive((i) => i - 1),
								children: "Previous module"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "saffron",
								onClick: markDone,
								children: completed.has(mod.id) ? active === modules.length - 1 ? "Completed" : "Next module" : "Mark complete"
							})]
						}),
						progress?.completedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-forest",
							children: "You have finished this course."
						})
					]
				})]
			}),
			related.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Next:",
					" ",
					related.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/courses/$courseId",
						params: { courseId: c.id },
						className: "font-medium text-saffron hover:underline",
						children: c.title
					}), i < related.length - 1 ? " · " : ""] }, c.id))
				]
			})
		]
	});
}
//#endregion
export { CoursePage as component };
