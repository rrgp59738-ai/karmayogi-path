import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as modulesFor, n as COMPETENCIES, r as COURSES, t as CATEGORY_LABEL, u as roleById } from "./catalog-7qHhzf7T.mjs";
import { l as proficiency, o as useAppStore, s as useHydrated } from "./router-C5Kd15x_.mjs";
import { t as Badge } from "./badge-CUilnUdH.mjs";
import { t as Button } from "./button-BjATLKEN.mjs";
import { t as Card } from "./card-CJLH9mWJ.mjs";
import { a as PolarGrid, i as PolarRadiusAxis, n as Radar, o as ResponsiveContainer, r as PolarAngleAxis, t as RadarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/progress-5U-_2leb.js
var import_jsx_runtime = require_jsx_runtime();
function GapRadar({ scores }) {
	const data = COMPETENCIES.map((c) => ({
		name: c.short,
		score: scores[c.id]?.score ?? 0
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-72 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
				data,
				cx: "50%",
				cy: "50%",
				outerRadius: "72%",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: "var(--color-line)" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
						dataKey: "name",
						tick: {
							fill: "var(--color-muted)",
							fontSize: 11
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
						angle: 90,
						domain: [0, 100],
						tick: false,
						axisLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
						name: "Proficiency",
						dataKey: "score",
						stroke: "var(--color-navy)",
						fill: "var(--color-navy)",
						fillOpacity: .18,
						strokeWidth: 2
					})
				]
			})
		})
	});
}
function ProgressPage() {
	const hydrated = useHydrated();
	const profile = useAppStore((s) => s.profile);
	const scores = useAppStore((s) => s.scores);
	const attempts = useAppStore((s) => s.attempts);
	const courseProgress = useAppStore((s) => s.courseProgress);
	const clearProfile = useAppStore((s) => s.clearProfile);
	const role = profile ? roleById(profile.roleId) : void 0;
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-72 animate-pulse rounded-xl bg-navy/8" });
	const finishedCourses = Object.values(courseProgress).filter((p) => p.completedAt).length;
	const minutes = Object.values(courseProgress).reduce((sum, p) => {
		const course = COURSES.find((c) => c.id === p.courseId);
		if (!course) return sum;
		const mods = modulesFor(course.id);
		const per = course.durationMin / Math.max(mods.length, 1);
		return sum + Math.round(per * p.completedModuleIds.length);
	}, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col justify-between gap-4 md:flex-row md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.2em] text-saffron",
						children: "Progress"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl font-semibold text-navy md:text-4xl",
						children: "The competency map"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-muted",
						children: profile ? `${profile.name} · ${role?.name ?? "Official"}. Scores blend each new paper with what came before.` : "Set your role so the map knows which chair to judge."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/diagnose",
						children: "Sit a diagnostic"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-muted",
						children: "Papers sat"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl font-semibold tabular-nums text-navy",
						children: attempts.length
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-muted",
						children: "Courses finished"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl font-semibold tabular-nums text-navy",
						children: finishedCourses
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-muted",
						children: "Minutes on Path"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl font-semibold tabular-nums text-navy",
						children: minutes
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4 md:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold text-navy",
						children: "Radar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Untested competencies sit at zero until you sit a paper that touches them."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GapRadar, { scores })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid gap-3 md:grid-cols-2",
				children: COMPETENCIES.map((c) => {
					const s = scores[c.id];
					const p = proficiency(s?.score);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "flex items-start justify-between gap-3 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-lg font-semibold text-navy",
									children: c.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: CATEGORY_LABEL[c.category] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: c.blurb
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted",
								children: s ? `${s.attempts} sitting${s.attempts === 1 ? "" : "s"}` : "No sitting yet"
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl font-semibold tabular-nums text-navy",
								children: s ? `${s.score}` : "—"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: p.tone,
								children: p.label
							})]
						})]
					}, c.id);
				})
			}),
			attempts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 font-display text-2xl font-semibold text-navy",
				children: "Recent papers"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: attempts.slice(0, 8).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/results/$attemptId",
					params: { attemptId: a.id },
					className: "flex items-center justify-between rounded-lg bg-paper-raised px-4 py-3 shadow-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium text-navy",
						children: a.quiz.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: new Date(a.completedAt).toLocaleString("en-IN", {
							day: "numeric",
							month: "short",
							hour: "2-digit",
							minute: "2-digit"
						})
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-lg font-semibold tabular-nums text-navy",
						children: [a.score, "%"]
					})]
				}) }, a.id))
			})] }),
			profile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => clearProfile(),
				className: "text-sm text-muted underline-offset-2 hover:text-danger hover:underline",
				children: "Clear this desk (local only)"
			})
		]
	});
}
//#endregion
export { ProgressPage as component };
