import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useNavigate, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as COMPETENCIES, t as CATEGORY_LABEL, u as roleById } from "./catalog-7qHhzf7T.mjs";
import { a as LoaderCircle, i as Sparkles } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Route$6, d as cn, o as useAppStore } from "./router-C5Kd15x_.mjs";
import { t as Badge } from "./badge-CUilnUdH.mjs";
import { t as Button } from "./button-BjATLKEN.mjs";
import { n as Label, r as SelectField } from "./input-D2PE5WSI.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as buildRoleQuiz, t as buildBankQuiz } from "./quiz-engine-DNPRNqzs.mjs";
import { t as Card } from "./card-CJLH9mWJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/diagnose-DAw7l2i0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var generateAiQuiz = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("3cf293fe08bc0108cc7a9d13c122613027f8699ca7b86f27129e96ca914a8e0f"));
function Diagnose() {
	const { competency: preselect } = Route$6.useSearch();
	const navigate = useNavigate();
	const profile = useAppStore((s) => s.profile);
	const setActiveQuiz = useAppStore((s) => s.setActiveQuiz);
	const role = profile ? roleById(profile.roleId) : void 0;
	const [competencyId, setCompetencyId] = (0, import_react.useState)(preselect && COMPETENCIES.some((c) => c.id === preselect) ? preselect : profile?.workFocus[0] ?? "noting");
	const [difficulty, setDifficulty] = (0, import_react.useState)("practitioner");
	const [busy, setBusy] = (0, import_react.useState)(null);
	const selected = (0, import_react.useMemo)(() => COMPETENCIES.find((c) => c.id === competencyId), [competencyId]);
	function startQuiz(builder) {
		const quiz = builder();
		if (!quiz) {
			toast.error("No questions in this set yet.");
			return;
		}
		setActiveQuiz(quiz);
		navigate({
			to: "/quiz/$quizId",
			params: { quizId: quiz.id }
		});
	}
	async function startAi() {
		setBusy("ai");
		try {
			const result = await generateAiQuiz({ data: {
				competencyId,
				roleName: role?.name ?? "Government official",
				designation: profile?.designation ?? "",
				ministry: profile?.ministry ?? "",
				yearsOfService: profile?.yearsOfService ?? 5,
				difficulty,
				workFocus: profile?.workFocus ?? []
			} });
			if (!result.ok) {
				toast.error(result.error);
				return;
			}
			setActiveQuiz(result.quiz);
			navigate({
				to: "/quiz/$quizId",
				params: { quizId: result.quiz.id }
			});
		} catch {
			toast.error("Could not generate a quiz. Use the curated diagnostic.");
		} finally {
			setBusy(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.2em] text-saffron",
						children: "Diagnose"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl font-semibold text-navy md:text-4xl",
						children: "Test the chair, not the syllabus"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "Sit a role diagnostic drawn from your work, a curated set on one competency, or ask Grok to write a custom paper for this designation."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col gap-4 md:flex-row md:items-center md:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold text-navy",
					children: "Role diagnostic"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 max-w-xl text-sm text-muted",
					children: [
						"Eight questions mixed from ",
						role?.name ?? "a general official chair",
						". Instant — no wait. Best first sitting of the week."
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "saffron",
					disabled: busy !== null,
					onClick: () => {
						setBusy("role");
						const quiz = buildRoleQuiz(profile ?? {
							name: "Officer",
							roleId: "secretariat",
							designation: "",
							ministry: "",
							yearsOfService: 5,
							workFocus: []
						});
						setActiveQuiz(quiz);
						navigate({
							to: "/quiz/$quizId",
							params: { quizId: quiz.id }
						});
					},
					children: [busy === "role" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : null, "Start role diagnostic"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 font-display text-2xl font-semibold text-navy",
				children: "One competency"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 md:grid-cols-4",
				children: COMPETENCIES.map((c) => {
					const on = c.id === competencyId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setCompetencyId(c.id),
						className: cn("rounded-lg px-3 py-3 text-left shadow-border transition-colors duration-150", on ? "bg-navy text-primary-foreground" : "bg-paper-raised hover:bg-paper"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("text-[10px] font-semibold uppercase tracking-wider", on ? "text-saffron" : "text-muted"),
							children: CATEGORY_LABEL[c.category]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block font-medium leading-snug",
							children: c.short
						})]
					}, c.id);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: selected ? CATEGORY_LABEL[selected.category] : "Competency" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 font-display text-2xl font-semibold text-navy",
							children: selected?.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: selected?.blurb
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "difficulty",
							children: "Pitch"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectField, {
							id: "difficulty",
							value: difficulty,
							onChange: (e) => setDifficulty(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "foundation",
									children: "Foundation"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "practitioner",
									children: "Practitioner"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "advanced",
									children: "Advanced"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "flex-1",
							disabled: busy !== null,
							onClick: () => {
								setBusy("bank");
								startQuiz(() => buildBankQuiz({
									competencyId,
									difficulty
								}));
								setBusy(null);
							},
							children: "Curated diagnostic"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "flex-1",
							variant: "outline",
							disabled: busy !== null,
							onClick: () => void startAi(),
							children: [busy === "ai" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), "Generate with Grok"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Grok writes an original eight-question paper for this role and pitch. If the service is unavailable, the curated set still runs."
					})
				]
			})
		]
	});
}
//#endregion
export { Diagnose as component };
