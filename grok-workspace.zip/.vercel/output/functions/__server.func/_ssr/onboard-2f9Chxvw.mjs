import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useNavigate, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as MINISTRIES, n as COMPETENCIES, o as ROLES } from "./catalog-7qHhzf7T.mjs";
import { d as cn, o as useAppStore } from "./router-C5Kd15x_.mjs";
import { t as Button } from "./button-BjATLKEN.mjs";
import { n as Label, r as SelectField, t as Input } from "./input-D2PE5WSI.mjs";
import { t as Card } from "./card-CJLH9mWJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/onboard-2f9Chxvw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Onboard() {
	const navigate = useNavigate();
	const existing = useAppStore((s) => s.profile);
	const setProfile = useAppStore((s) => s.setProfile);
	const [step, setStep] = (0, import_react.useState)(0);
	const [draft, setDraft] = (0, import_react.useState)(existing ?? {
		name: "",
		roleId: "ias",
		designation: "",
		ministry: MINISTRIES[3],
		yearsOfService: 5,
		workFocus: []
	});
	const role = ROLES.find((r) => r.id === draft.roleId);
	function toggleFocus(id) {
		setDraft((d) => {
			const workFocus = d.workFocus.includes(id) ? d.workFocus.filter((x) => x !== id) : [...d.workFocus, id].slice(0, 6);
			return {
				...d,
				workFocus
			};
		});
	}
	function save() {
		const name = draft.name.trim() || "Officer";
		const workFocus = draft.workFocus.length > 0 ? draft.workFocus : role?.competencyIds.slice(0, 4) ?? [];
		setProfile({
			...draft,
			name,
			workFocus
		});
		navigate({ to: "/" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold uppercase tracking-[0.2em] text-saffron",
					children: [
						"Step ",
						step + 1,
						" of 3"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl font-semibold text-navy",
					children: "Set your role"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Diagnostics and course recommendations follow the chair you sit in, not a generic catalogue."
				})
			] }),
			step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "name",
						children: "Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "name",
						value: draft.name,
						onChange: (e) => setDraft({
							...draft,
							name: e.target.value
						}),
						placeholder: "As you would write it on a note",
						autoComplete: "name"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "designation",
						children: "Designation"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "designation",
						value: draft.designation,
						onChange: (e) => setDraft({
							...draft,
							designation: e.target.value
						}),
						placeholder: "Deputy Secretary, CMO, BDO…"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "years",
						children: "Years of service"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "years",
						type: "number",
						min: 0,
						max: 45,
						value: draft.yearsOfService,
						onChange: (e) => setDraft({
							...draft,
							yearsOfService: Number(e.target.value) || 0
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						onClick: () => setStep(1),
						children: "Continue"
					})
				]
			}),
			step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "ministry",
						children: "Ministry / department"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
						id: "ministry",
						value: draft.ministry,
						onChange: (e) => setDraft({
							...draft,
							ministry: e.target.value
						}),
						children: MINISTRIES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: m,
							children: m
						}, m))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "mb-3 text-sm font-medium",
						children: "The chair"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2",
						children: ROLES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setDraft({
								...draft,
								roleId: r.id,
								workFocus: r.competencyIds.slice(0, 4)
							}),
							className: cn("rounded-md px-4 py-3 text-left shadow-border transition-colors duration-150", draft.roleId === r.id ? "bg-navy text-primary-foreground" : "bg-paper hover:bg-paper-raised"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-medium",
								children: r.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("mt-0.5 block text-sm", draft.roleId === r.id ? "text-primary-foreground/70" : "text-muted"),
								children: r.blurb
							})]
						}, r.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "flex-1",
							onClick: () => setStep(0),
							children: "Back"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "flex-1",
							onClick: () => setStep(2),
							children: "Continue"
						})]
					})
				]
			}),
			step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Pick up to six competencies that the work actually demands this year. We have pre-selected those typical of ",
							role?.name,
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: COMPETENCIES.map((c) => {
							const on = draft.workFocus.includes(c.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toggleFocus(c.id),
								className: cn("rounded-full px-3 py-2 text-sm font-medium shadow-border", on ? "bg-navy text-primary-foreground" : "bg-paper text-ink"),
								children: c.name
							}, c.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "flex-1",
							onClick: () => setStep(1),
							children: "Back"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "flex-1",
							variant: "saffron",
							onClick: save,
							children: "Save and go to the desk"
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Onboard as component };
