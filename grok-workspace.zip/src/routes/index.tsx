import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Compass, GraduationCap, Target } from "lucide-react";
import { CourseCard } from "@/components/course-card";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { COMPETENCIES, COURSES, modulesFor, roleById } from "@/lib/catalog";
import { proficiency, recommendCourses } from "@/lib/recommend";
import { useAppStore, useHydrated } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const hydrated = useHydrated();
  const profile = useAppStore((s) => s.profile);
  if (hydrated && profile) return <Dashboard />;
  return <Landing />;
}

function Landing() {
  return (
    <div className="stagger-in space-y-10">
      <section className="overflow-hidden rounded-xl bg-navy px-6 py-10 text-primary-foreground md:px-12 md:py-14">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-saffron">
          Mission-ready learning
        </p>
        <h1 className="mt-3 max-w-2xl font-display text-4xl font-semibold leading-tight tracking-tight md:text-5xl">
          Find the gap. Learn what the chair actually needs.
        </h1>
        <p className="mt-4 max-w-xl text-base leading-relaxed text-primary-foreground/75">
          Karmayogi Path is a diagnostic companion for Indian government officials.
          Sit a short quiz on the competencies of your role, see where the work is
          thin, and take a course built for that weakness — noting, propriety,
          citizen service, disaster command, and more.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Button variant="saffron" size="lg" asChild>
            <Link to="/onboard">
              Set your role
              <ArrowRight />
            </Link>
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="border-0 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/16"
            asChild
          >
            <Link to="/courses">Browse courses</Link>
          </Button>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {[
          {
            icon: Compass,
            title: "Diagnose",
            body: "A role diagnostic or a custom AI quiz on one competency. Eight questions. No theatre.",
          },
          {
            icon: Target,
            title: "See the weakness",
            body: "Topic tags you missed become a map — ethics, GeM, RTI, first 72 hours, denominators.",
          },
          {
            icon: GraduationCap,
            title: "Take the course",
            body: "Short original modules in the Mission Karmayogi spirit: behavioural, functional, domain.",
          },
        ].map((item) => (
          <Card key={item.title} className="p-5">
            <item.icon className="size-5 text-saffron" />
            <h2 className="mt-3 font-display text-xl font-semibold text-navy">{item.title}</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">{item.body}</p>
          </Card>
        ))}
      </section>

      <section>
        <div className="mb-4 flex items-end justify-between gap-4">
          <h2 className="font-display text-2xl font-semibold text-navy">Twelve competencies</h2>
          <Link to="/diagnose" className="text-sm font-medium text-saffron hover:underline">
            Test one
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {COMPETENCIES.map((c) => (
            <Link
              key={c.id}
              to="/diagnose"
              search={{ competency: c.id }}
              className="rounded-lg bg-paper-raised p-4 shadow-border transition-shadow duration-150 hover:shadow-[var(--shadow-border-hover)]"
            >
              <Badge>{c.category === "behavioral" ? "Behavioural" : c.category === "functional" ? "Functional" : "Domain"}</Badge>
              <p className="mt-3 font-display text-lg font-semibold leading-snug text-navy">{c.short}</p>
              <p className="mt-1 line-clamp-2 text-xs text-muted">{c.blurb}</p>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="mb-4 font-display text-2xl font-semibold text-navy">Start a course</h2>
        <div className="grid gap-4 md:grid-cols-3">
          {COURSES.slice(0, 3).map((course) => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      </section>
    </div>
  );
}

function Dashboard() {
  const profile = useAppStore((s) => s.profile)!;
  const scores = useAppStore((s) => s.scores);
  const courseProgress = useAppStore((s) => s.courseProgress);
  const attempts = useAppStore((s) => s.attempts);
  const role = roleById(profile.roleId);
  const recs = recommendCourses(profile, scores, 3);
  const inProgress = Object.values(courseProgress).filter((p) => !p.completedAt);
  const weak = Object.values(scores)
    .filter((s) => s.score < 75)
    .sort((a, b) => a.score - b.score)
    .slice(0, 3);

  return (
    <div className="stagger-in space-y-8">
      <section className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-saffron">
            {role?.cadre} · {profile.ministry}
          </p>
          <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight text-navy md:text-4xl">
            {greeting()}, {firstName(profile.name)}
          </h1>
          <p className="mt-2 max-w-xl text-muted">
            {attempts.length === 0
              ? "You have not sat a diagnostic yet. Ten minutes will tell you more than a year of untested circulars."
              : `${attempts.length} diagnostic${attempts.length === 1 ? "" : "s"} on file. The map updates each time you sit one.`}
          </p>
        </div>
        <Button variant="saffron" asChild>
          <Link to="/diagnose">
            Sit a diagnostic
            <ArrowRight />
          </Link>
        </Button>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <Card>
          <p className="text-xs font-medium uppercase tracking-wider text-muted">Diagnostics</p>
          <p className="mt-2 font-display text-3xl font-semibold tabular-nums text-navy">
            {attempts.length}
          </p>
        </Card>
        <Card>
          <p className="text-xs font-medium uppercase tracking-wider text-muted">Courses in motion</p>
          <p className="mt-2 font-display text-3xl font-semibold tabular-nums text-navy">
            {inProgress.length}
          </p>
        </Card>
        <Card>
          <p className="text-xs font-medium uppercase tracking-wider text-muted">Thin spots</p>
          <p className="mt-2 font-display text-3xl font-semibold tabular-nums text-navy">
            {weak.length}
          </p>
        </Card>
      </section>

      {weak.length > 0 && (
        <section>
          <h2 className="mb-3 font-display text-2xl font-semibold text-navy">Where the work is thin</h2>
          <div className="grid gap-3 md:grid-cols-3">
            {weak.map((s) => {
              const c = COMPETENCIES.find((x) => x.id === s.competencyId);
              const p = proficiency(s.score);
              return (
                <Card key={s.competencyId} className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-display text-lg font-semibold text-navy">{c?.name}</p>
                    <p className="mt-1 text-sm text-muted">{c?.blurb}</p>
                  </div>
                  <Badge tone={p.tone}>{s.score}%</Badge>
                </Card>
              );
            })}
          </div>
        </section>
      )}

      {inProgress.length > 0 && (
        <section>
          <h2 className="mb-3 font-display text-2xl font-semibold text-navy">Continue</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {inProgress.slice(0, 2).map((p) => {
              const course = COURSES.find((c) => c.id === p.courseId);
              if (!course) return null;
              const total = modulesFor(course.id).length;
              return (
                <CourseCard
                  key={course.id}
                  course={course}
                  progress={{ completed: p.completedModuleIds.length, total }}
                />
              );
            })}
          </div>
        </section>
      )}

      <section>
        <div className="mb-3 flex items-end justify-between">
          <h2 className="font-display text-2xl font-semibold text-navy">Recommended for your chair</h2>
          <Link to="/courses" className="text-sm font-medium text-saffron hover:underline">
            All courses
          </Link>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          {recs.map((course) => {
            const p = courseProgress[course.id];
            const total = modulesFor(course.id).length;
            return (
              <CourseCard
                key={course.id}
                course={course}
                progress={
                  p
                    ? {
                        completed: p.completedModuleIds.length,
                        total,
                        done: Boolean(p.completedAt),
                      }
                    : undefined
                }
              />
            );
          })}
        </div>
      </section>
    </div>
  );
}

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

function firstName(name: string) {
  return name.trim().split(/\s+/)[0] || name;
}
