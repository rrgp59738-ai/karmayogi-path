import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, ChevronLeft, Clock } from "lucide-react";
import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  CATEGORY_LABEL,
  LEVEL_LABEL,
  competencyById,
  courseById,
  modulesFor,
} from "@/lib/catalog";
import { cn } from "@/lib/cn";
import { coursesForCompetency } from "@/lib/recommend";
import { useAppStore, useHydrated } from "@/lib/store";

export const Route = createFileRoute("/courses/$courseId")({ component: CoursePage });

function CoursePage() {
  const { courseId } = Route.useParams();
  const course = courseById(courseId);
  const modules = modulesFor(courseId);
  const hydrated = useHydrated();
  const progress = useAppStore((s) => s.courseProgress[courseId]);
  const startCourse = useAppStore((s) => s.startCourse);
  const completeModule = useAppStore((s) => s.completeModule);
  const [active, setActive] = useState(0);

  useEffect(() => {
    if (!hydrated || !course) return;
    startCourse(course.id);
  }, [hydrated, course, startCourse]);

  useEffect(() => {
    setActive(0);
  }, [courseId]);

  if (!course) {
    return (
      <div className="space-y-4 py-12 text-center">
        <h1 className="font-display text-2xl font-semibold text-navy">Course not found</h1>
        <Button asChild>
          <Link to="/courses">Back to courses</Link>
        </Button>
      </div>
    );
  }

  const mod = modules[active];
  const completed = new Set(progress?.completedModuleIds ?? []);
  const related = course.competencyIds.flatMap(coursesForCompetency).filter((c) => c.id !== course.id).slice(0, 2);

  function markDone() {
    if (!mod || !course) return;
    completeModule(course.id, mod.id, modules.length);
    if (active < modules.length - 1) setActive((i) => i + 1);
  }

  return (
    <div className="space-y-6">
      <Link
        to="/courses"
        className="inline-flex items-center gap-1 text-sm font-medium text-muted hover:text-navy"
      >
        <ChevronLeft className="size-4" />
        All courses
      </Link>

      <header className="rounded-xl bg-navy px-6 py-8 text-primary-foreground md:px-10">
        <div className="flex flex-wrap gap-2">
          <Badge className="bg-primary-foreground/10 text-primary-foreground">
            {CATEGORY_LABEL[course.category]}
          </Badge>
          <Badge className="bg-saffron/90 text-saffron-fg">{LEVEL_LABEL[course.level]}</Badge>
        </div>
        <h1 className="mt-4 font-display text-3xl font-semibold tracking-tight md:text-4xl">
          {course.title}
        </h1>
        <p className="mt-3 max-w-2xl text-primary-foreground/75">{course.subtitle}</p>
        <p className="mt-4 flex flex-wrap items-center gap-3 text-sm text-primary-foreground/60">
          <span className="inline-flex items-center gap-1">
            <Clock className="size-4" /> {course.durationMin} min
          </span>
          <span>{course.audience}</span>
          {course.competencyIds.map((id) => (
            <span key={id}>{competencyById(id)?.name}</span>
          ))}
        </p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[220px_minmax(0,1fr)]">
        <ol className="flex gap-2 overflow-x-auto lg:flex-col lg:overflow-visible">
          {modules.map((m, i) => {
            const done = completed.has(m.id);
            const on = i === active;
            return (
              <li key={m.id} className="min-w-[11rem] lg:min-w-0">
                <button
                  type="button"
                  onClick={() => setActive(i)}
                  className={cn(
                    "flex w-full items-start gap-2 rounded-md px-3 py-3 text-left text-sm shadow-border",
                    on ? "bg-navy text-primary-foreground" : "bg-paper-raised",
                  )}
                >
                  <span
                    className={cn(
                      "mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold",
                      done
                        ? "bg-forest text-primary-foreground"
                        : on
                          ? "bg-saffron text-saffron-fg"
                          : "bg-navy/10 text-navy",
                    )}
                  >
                    {done ? <Check className="size-3" /> : i + 1}
                  </span>
                  <span>
                    <span className="block font-medium leading-snug">{m.title}</span>
                    <span className={cn("text-xs", on ? "text-primary-foreground/60" : "text-muted")}>
                      {m.minutes} min
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ol>

        {mod && (
          <article className="rounded-xl bg-paper-raised p-5 shadow-border md:p-8">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-saffron">
              Module {active + 1}
            </p>
            <h2 className="mt-2 font-display text-2xl font-semibold text-navy">{mod.title}</h2>
            <div className="mt-5 space-y-4 text-[1.05rem] leading-relaxed text-ink">
              {mod.paragraphs.map((p) => (
                <p key={p.slice(0, 24)}>{p}</p>
              ))}
            </div>
            <div className="mt-8 rounded-lg bg-navy/5 p-4">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted">
                Takeaways
              </p>
              <ul className="mt-2 space-y-2">
                {mod.takeaways.map((t) => (
                  <li key={t} className="flex gap-2 text-sm leading-snug text-navy">
                    <Check className="mt-0.5 size-4 shrink-0 text-forest" />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button variant="outline" disabled={active === 0} onClick={() => setActive((i) => i - 1)}>
                Previous module
              </Button>
              <Button variant="saffron" onClick={markDone}>
                {completed.has(mod.id)
                  ? active === modules.length - 1
                    ? "Completed"
                    : "Next module"
                  : "Mark complete"}
              </Button>
            </div>
            {progress?.completedAt && (
              <p className="mt-4 text-sm text-forest">You have finished this course.</p>
            )}
          </article>
        )}
      </div>

      {related.length > 0 && (
        <p className="text-sm text-muted">
          Next:{" "}
          {related.map((c, i) => (
            <span key={c.id}>
              <Link
                to="/courses/$courseId"
                params={{ courseId: c.id }}
                className="font-medium text-saffron hover:underline"
              >
                {c.title}
              </Link>
              {i < related.length - 1 ? " · " : ""}
            </span>
          ))}
        </p>
      )}
    </div>
  );
}
