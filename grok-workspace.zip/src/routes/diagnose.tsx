import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Loader2, Sparkles } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label, SelectField } from "@/components/ui/input";
import { CATEGORY_LABEL, COMPETENCIES, roleById } from "@/lib/catalog";
import { cn } from "@/lib/cn";
import { generateAiQuiz } from "@/lib/quiz-ai";
import { buildBankQuiz, buildRoleQuiz } from "@/lib/quiz-engine";
import { useAppStore } from "@/lib/store";
import type { QuizQuestion } from "@/lib/types";

type DiagnoseSearch = { competency?: string };

export const Route = createFileRoute("/diagnose")({
  validateSearch: (search: Record<string, unknown>): DiagnoseSearch => ({
    competency: typeof search.competency === "string" ? search.competency : undefined,
  }),
  component: Diagnose,
});

function Diagnose() {
  const { competency: preselect } = Route.useSearch();
  const navigate = useNavigate();
  const profile = useAppStore((s) => s.profile);
  const setActiveQuiz = useAppStore((s) => s.setActiveQuiz);
  const role = profile ? roleById(profile.roleId) : undefined;
  const [competencyId, setCompetencyId] = useState(
    preselect && COMPETENCIES.some((c) => c.id === preselect)
      ? preselect
      : (profile?.workFocus[0] ?? "noting"),
  );
  const [difficulty, setDifficulty] = useState<QuizQuestion["difficulty"]>("practitioner");
  const [busy, setBusy] = useState<"bank" | "ai" | "role" | null>(null);

  const selected = useMemo(
    () => COMPETENCIES.find((c) => c.id === competencyId),
    [competencyId],
  );

  function startQuiz(builder: () => ReturnType<typeof buildBankQuiz>) {
    const quiz = builder();
    if (!quiz) {
      toast.error("No questions in this set yet.");
      return;
    }
    setActiveQuiz(quiz);
    void navigate({ to: "/quiz/$quizId", params: { quizId: quiz.id } });
  }

  async function startAi() {
    setBusy("ai");
    try {
      const result = await generateAiQuiz({
        data: {
          competencyId,
          roleName: role?.name ?? "Government official",
          designation: profile?.designation ?? "",
          ministry: profile?.ministry ?? "",
          yearsOfService: profile?.yearsOfService ?? 5,
          difficulty,
          workFocus: profile?.workFocus ?? [],
        },
      });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      setActiveQuiz(result.quiz);
      void navigate({ to: "/quiz/$quizId", params: { quizId: result.quiz.id } });
    } catch {
      toast.error("Could not generate a quiz. Use the curated diagnostic.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-8">
      <header className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-saffron">Diagnose</p>
        <h1 className="mt-2 font-display text-3xl font-semibold text-navy md:text-4xl">
          Test the chair, not the syllabus
        </h1>
        <p className="mt-2 text-muted">
          Sit a role diagnostic drawn from your work, a curated set on one competency, or ask
          Grok to write a custom paper for this designation.
        </p>
      </header>

      <Card className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="font-display text-xl font-semibold text-navy">Role diagnostic</h2>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Eight questions mixed from {role?.name ?? "a general official chair"}. Instant —
            no wait. Best first sitting of the week.
          </p>
        </div>
        <Button
          variant="saffron"
          disabled={busy !== null}
          onClick={() => {
            setBusy("role");
            const quiz = buildRoleQuiz(
              profile ?? {
                name: "Officer",
                roleId: "secretariat",
                designation: "",
                ministry: "",
                yearsOfService: 5,
                workFocus: [],
              },
            );
            setActiveQuiz(quiz);
            void navigate({ to: "/quiz/$quizId", params: { quizId: quiz.id } });
          }}
        >
          {busy === "role" ? <Loader2 className="animate-spin" /> : null}
          Start role diagnostic
        </Button>
      </Card>

      <section>
        <h2 className="mb-3 font-display text-2xl font-semibold text-navy">One competency</h2>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          {COMPETENCIES.map((c) => {
            const on = c.id === competencyId;
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => setCompetencyId(c.id)}
                className={cn(
                  "rounded-lg px-3 py-3 text-left shadow-border transition-colors duration-150",
                  on ? "bg-navy text-primary-foreground" : "bg-paper-raised hover:bg-paper",
                )}
              >
                <span
                  className={cn(
                    "text-[10px] font-semibold uppercase tracking-wider",
                    on ? "text-saffron" : "text-muted",
                  )}
                >
                  {CATEGORY_LABEL[c.category]}
                </span>
                <span className="mt-1 block font-medium leading-snug">{c.short}</span>
              </button>
            );
          })}
        </div>
      </section>

      <Card className="space-y-5">
        <div>
          <Badge>{selected ? CATEGORY_LABEL[selected.category] : "Competency"}</Badge>
          <h3 className="mt-2 font-display text-2xl font-semibold text-navy">
            {selected?.name}
          </h3>
          <p className="mt-1 text-sm text-muted">{selected?.blurb}</p>
        </div>
        <div className="max-w-xs">
          <Label htmlFor="difficulty">Pitch</Label>
          <SelectField
            id="difficulty"
            value={difficulty}
            onChange={(e) =>
              setDifficulty(e.target.value as QuizQuestion["difficulty"])
            }
          >
            <option value="foundation">Foundation</option>
            <option value="practitioner">Practitioner</option>
            <option value="advanced">Advanced</option>
          </SelectField>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row">
          <Button
            className="flex-1"
            disabled={busy !== null}
            onClick={() => {
              setBusy("bank");
              startQuiz(() =>
                buildBankQuiz({
                  competencyId,
                  difficulty,
                }),
              );
              setBusy(null);
            }}
          >
            Curated diagnostic
          </Button>
          <Button
            className="flex-1"
            variant="outline"
            disabled={busy !== null}
            onClick={() => void startAi()}
          >
            {busy === "ai" ? (
              <Loader2 className="animate-spin" />
            ) : (
              <Sparkles className="size-4" />
            )}
            Generate with Grok
          </Button>
        </div>
        <p className="text-xs text-muted">
          Grok writes an original eight-question paper for this role and pitch. If the service
          is unavailable, the curated set still runs.
        </p>
      </Card>
    </div>
  );
}
