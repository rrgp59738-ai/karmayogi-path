import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { CourseCard } from "@/components/course-card";
import { Input } from "@/components/ui/input";
import { CATEGORY_LABEL, COURSES, modulesFor } from "@/lib/catalog";
import { cn } from "@/lib/cn";
import { recommendCourses } from "@/lib/recommend";
import { useAppStore, useHydrated } from "@/lib/store";
import type { CompetencyCategory } from "@/lib/types";

export const Route = createFileRoute("/courses/")({ component: CoursesPage });

const FILTERS: Array<{ id: "all" | CompetencyCategory; label: string }> = [
  { id: "all", label: "All" },
  { id: "behavioral", label: "Behavioural" },
  { id: "functional", label: "Functional" },
  { id: "domain", label: "Domain" },
];

function CoursesPage() {
  const hydrated = useHydrated();
  const profile = useAppStore((s) => s.profile);
  const scores = useAppStore((s) => s.scores);
  const courseProgress = useAppStore((s) => s.courseProgress);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");
  const [q, setQ] = useState("");

  const recommended = hydrated ? recommendCourses(profile, scores, 3) : [];

  const list = useMemo(() => {
    const query = q.trim().toLowerCase();
    return COURSES.filter((c) => {
      if (filter !== "all" && c.category !== filter) return false;
      if (!query) return true;
      return (
        c.title.toLowerCase().includes(query) ||
        c.subtitle.toLowerCase().includes(query) ||
        CATEGORY_LABEL[c.category].toLowerCase().includes(query)
      );
    });
  }, [filter, q]);

  return (
    <div className="space-y-8">
      <header className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-saffron">Learn</p>
        <h1 className="mt-2 font-display text-3xl font-semibold text-navy md:text-4xl">
          Courses for the work, not the calendar
        </h1>
        <p className="mt-2 text-muted">
          Original competency-building modules in the spirit of Mission Karmayogi —
          short enough to finish between files, dense enough to change the next noting.
        </p>
      </header>

      {hydrated && recommended.length > 0 && profile && (
        <section>
          <h2 className="mb-3 font-display text-2xl font-semibold text-navy">For your gaps</h2>
          <div className="grid gap-4 md:grid-cols-3">
            {recommended.map((course) => {
              const p = courseProgress[course.id];
              const total = modulesFor(course.id).length;
              return (
                <CourseCard
                  key={course.id}
                  course={course}
                  featured
                  progress={
                    p
                      ? {
                          completed: p.completedModuleIds.length,
                          total,
                          done: Boolean(p.completedAt),
                        }
                      : undefined
                  }
                />
              );
            })}
          </div>
        </section>
      )}

      <div className="flex flex-col gap-3 md:flex-row md:items-center">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search courses"
          aria-label="Search courses"
          className="md:max-w-xs"
        />
        <div className="flex flex-wrap gap-2">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              className={cn(
                "h-11 rounded-full px-4 text-sm font-medium shadow-border",
                filter === f.id ? "bg-navy text-primary-foreground" : "bg-paper-raised text-ink",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {list.map((course) => {
          const p = courseProgress[course.id];
          const total = modulesFor(course.id).length;
          return (
            <CourseCard
              key={course.id}
              course={course}
              progress={
                p
                  ? {
                      completed: p.completedModuleIds.length,
                      total,
                      done: Boolean(p.completedAt),
                    }
                  : undefined
              }
            />
          );
        })}
      </div>
      {list.length === 0 && (
        <p className="text-sm text-muted">No course matches that search.</p>
      )}
    </div>
  );
}
