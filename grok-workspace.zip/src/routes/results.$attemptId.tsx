import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, X } from "lucide-react";
import { useState } from "react";
import { CourseCard } from "@/components/course-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { competencyById } from "@/lib/catalog";
import { cn } from "@/lib/cn";
import { coursesForCompetency } from "@/lib/recommend";
import { scoreAttempt } from "@/lib/quiz-engine";
import { useAppStore, useHydrated } from "@/lib/store";

export const Route = createFileRoute("/results/$attemptId")({ component: ResultsPage });

function ResultsPage() {
  const { attemptId } = Route.useParams();
  const hydrated = useHydrated();
  const attempts = useAppStore((s) => s.attempts);
  const attempt = attempts.find((a) => a.id === attemptId);
  const [open, setOpen] = useState<string | null>(null);

  if (!hydrated) {
    return <div className="h-64 animate-pulse rounded-xl bg-navy/8" />;
  }
  if (!attempt) {
    return (
      <div className="mx-auto max-w-lg space-y-4 py-12 text-center">
        <h1 className="font-display text-2xl font-semibold text-navy">Result not found</h1>
        <Button asChild>
          <Link to="/diagnose">Sit another diagnostic</Link>
        </Button>
      </div>
    );
  }

  const detail = scoreAttempt(attempt.quiz.questions, attempt.answers);
  const recs = [
    ...new Set(attempt.quiz.questions.map((q) => q.competencyId)),
  ].flatMap((id) => coursesForCompetency(id)).slice(0, 3);

  return (
    <div className="space-y-8">
      <section className="rounded-xl bg-navy px-6 py-8 text-primary-foreground md:px-10">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-saffron">Result</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">{attempt.quiz.title}</h1>
        <p className="mt-4 font-display text-5xl font-semibold tabular-nums">{attempt.score}%</p>
        <p className="mt-2 text-sm text-primary-foreground/70">
          {detail.correct} of {attempt.quiz.questions.length} correct
        </p>
        <span className="mt-3 inline-block rounded-full bg-primary-foreground/12 px-3 py-1 text-xs">
          {attempt.score >= 75 ? "Proficient sitting" : attempt.score >= 50 ? "Developing" : "Needs work"}
        </span>
        {attempt.weakTopics.length > 0 && (
          <div className="mt-5 flex flex-wrap gap-2">
            {attempt.weakTopics.map((t) => (
              <span
                key={t}
                className="rounded-full bg-primary-foreground/10 px-3 py-1 text-xs"
              >
                Gap · {t}
              </span>
            ))}
          </div>
        )}
      </section>

      {recs.length > 0 && (
        <section>
          <h2 className="mb-3 font-display text-2xl font-semibold text-navy">
            Courses for these gaps
          </h2>
          <div className="grid gap-4 md:grid-cols-3">
            {recs.map((c) => (
              <CourseCard key={c.id} course={c} />
            ))}
          </div>
        </section>
      )}

      <section className="space-y-3">
        <h2 className="font-display text-2xl font-semibold text-navy">Review</h2>
        {attempt.quiz.questions.map((q, i) => {
          const chosen = attempt.answers[i];
          const ok = chosen === q.correctIndex;
          const expanded = open === q.id;
          return (
            <Card key={q.id} className="p-4 md:p-5">
              <button
                type="button"
                className="flex w-full items-start gap-3 text-left"
                onClick={() => setOpen(expanded ? null : q.id)}
              >
                <span
                  className={cn(
                    "mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full",
                    ok ? "bg-forest/15 text-forest" : "bg-danger/12 text-danger",
                  )}
                >
                  {ok ? <Check className="size-3.5" /> : <X className="size-3.5" />}
                </span>
                <span className="flex-1">
                  <span className="block text-sm font-medium leading-snug text-navy">
                    {q.stem}
                  </span>
                  <span className="mt-1 flex flex-wrap gap-2">
                    <Badge tone={ok ? "strong" : "weak"}>{ok ? "Correct" : "Missed"}</Badge>
                    <Badge>{competencyById(q.competencyId)?.short}</Badge>
                    <Badge tone="saffron">{q.topicTag}</Badge>
                  </span>
                </span>
              </button>
              {expanded && (
                <div className="mt-4 space-y-2 border-t border-line pt-4 text-sm">
                  {q.options.map((opt, oi) => {
                    const isCorrect = oi === q.correctIndex;
                    const isChosen = oi === chosen;
                    return (
                      <p
                        key={opt}
                        className={cn(
                          "rounded-sm px-3 py-2",
                          isCorrect && "bg-forest/10 text-forest",
                          isChosen && !isCorrect && "bg-danger/8 text-danger",
                        )}
                      >
                        {opt}
                        {isCorrect ? " — key" : isChosen ? " — your answer" : ""}
                      </p>
                    );
                  })}
                  <p className="pt-2 leading-relaxed text-muted">{q.explanation}</p>
                </div>
              )}
            </Card>
          );
        })}
      </section>

      <div className="flex flex-wrap gap-3">
        <Button asChild>
          <Link to="/diagnose">Another diagnostic</Link>
        </Button>
        <Button variant="outline" asChild>
          <Link to="/progress">Open the map</Link>
        </Button>
      </div>
    </div>
  );
}
