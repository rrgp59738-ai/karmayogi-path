import { createFileRoute, Link } from "@tanstack/react-router";
import { GapRadar } from "@/components/gap-radar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CATEGORY_LABEL, COMPETENCIES, COURSES, modulesFor, roleById } from "@/lib/catalog";
import { proficiency } from "@/lib/recommend";
import { useAppStore, useHydrated } from "@/lib/store";

export const Route = createFileRoute("/progress")({ component: ProgressPage });

function ProgressPage() {
  const hydrated = useHydrated();
  const profile = useAppStore((s) => s.profile);
  const scores = useAppStore((s) => s.scores);
  const attempts = useAppStore((s) => s.attempts);
  const courseProgress = useAppStore((s) => s.courseProgress);
  const clearProfile = useAppStore((s) => s.clearProfile);
  const role = profile ? roleById(profile.roleId) : undefined;

  if (!hydrated) return <div className="h-72 animate-pulse rounded-xl bg-navy/8" />;

  const finishedCourses = Object.values(courseProgress).filter((p) => p.completedAt).length;
  const minutes = Object.values(courseProgress).reduce((sum, p) => {
    const course = COURSES.find((c) => c.id === p.courseId);
    if (!course) return sum;
    const mods = modulesFor(course.id);
    const per = course.durationMin / Math.max(mods.length, 1);
    return sum + Math.round(per * p.completedModuleIds.length);
  }, 0);

  return (
    <div className="space-y-8">
      <header className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-saffron">Progress</p>
          <h1 className="mt-2 font-display text-3xl font-semibold text-navy md:text-4xl">
            The competency map
          </h1>
          <p className="mt-2 max-w-xl text-muted">
            {profile
              ? `${profile.name} · ${role?.name ?? "Official"}. Scores blend each new paper with what came before.`
              : "Set your role so the map knows which chair to judge."}
          </p>
        </div>
        <Button asChild>
          <Link to="/diagnose">Sit a diagnostic</Link>
        </Button>
      </header>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <p className="text-xs font-medium uppercase tracking-wider text-muted">Papers sat</p>
          <p className="mt-2 font-display text-3xl font-semibold tabular-nums text-navy">
            {attempts.length}
          </p>
        </Card>
        <Card>
          <p className="text-xs font-medium uppercase tracking-wider text-muted">Courses finished</p>
          <p className="mt-2 font-display text-3xl font-semibold tabular-nums text-navy">
            {finishedCourses}
          </p>
        </Card>
        <Card>
          <p className="text-xs font-medium uppercase tracking-wider text-muted">Minutes on Path</p>
          <p className="mt-2 font-display text-3xl font-semibold tabular-nums text-navy">
            {minutes}
          </p>
        </Card>
      </div>

      <Card className="p-4 md:p-6">
        <h2 className="font-display text-xl font-semibold text-navy">Radar</h2>
        <p className="mt-1 text-sm text-muted">
          Untested competencies sit at zero until you sit a paper that touches them.
        </p>
        <GapRadar scores={scores} />
      </Card>

      <section className="grid gap-3 md:grid-cols-2">
        {COMPETENCIES.map((c) => {
          const s = scores[c.id];
          const p = proficiency(s?.score);
          return (
            <Card key={c.id} className="flex items-start justify-between gap-3 p-4">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-display text-lg font-semibold text-navy">{c.name}</h3>
                  <Badge>{CATEGORY_LABEL[c.category]}</Badge>
                </div>
                <p className="mt-1 text-sm text-muted">{c.blurb}</p>
                <p className="mt-2 text-xs text-muted">
                  {s ? `${s.attempts} sitting${s.attempts === 1 ? "" : "s"}` : "No sitting yet"}
                </p>
              </div>
              <div className="text-right">
                <p className="font-display text-2xl font-semibold tabular-nums text-navy">
                  {s ? `${s.score}` : "—"}
                </p>
                <Badge tone={p.tone}>{p.label}</Badge>
              </div>
            </Card>
          );
        })}
      </section>

      {attempts.length > 0 && (
        <section>
          <h2 className="mb-3 font-display text-2xl font-semibold text-navy">Recent papers</h2>
          <ul className="space-y-2">
            {attempts.slice(0, 8).map((a) => (
              <li key={a.id}>
                <Link
                  to="/results/$attemptId"
                  params={{ attemptId: a.id }}
                  className="flex items-center justify-between rounded-lg bg-paper-raised px-4 py-3 shadow-border"
                >
                  <span>
                    <span className="block text-sm font-medium text-navy">{a.quiz.title}</span>
                    <span className="text-xs text-muted">
                      {new Date(a.completedAt).toLocaleString("en-IN", {
                        day: "numeric",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </span>
                  <span className="font-display text-lg font-semibold tabular-nums text-navy">
                    {a.score}%
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}

      {profile && (
        <button
          type="button"
          onClick={() => clearProfile()}
          className="text-sm text-muted underline-offset-2 hover:text-danger hover:underline"
        >
          Clear this desk (local only)
        </button>
      )}
    </div>
  );
}
