import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input, Label, SelectField } from "@/components/ui/input";
import { COMPETENCIES, MINISTRIES, ROLES } from "@/lib/catalog";
import { cn } from "@/lib/cn";
import { useAppStore } from "@/lib/store";
import type { OfficialProfile } from "@/lib/types";

export const Route = createFileRoute("/onboard")({ component: Onboard });

function Onboard() {
  const navigate = useNavigate();
  const existing = useAppStore((s) => s.profile);
  const setProfile = useAppStore((s) => s.setProfile);
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState<OfficialProfile>(
    existing ?? {
      name: "",
      roleId: "ias",
      designation: "",
      ministry: MINISTRIES[3],
      yearsOfService: 5,
      workFocus: [],
    },
  );

  const role = ROLES.find((r) => r.id === draft.roleId);

  function toggleFocus(id: string) {
    setDraft((d) => {
      const has = d.workFocus.includes(id);
      const workFocus = has
        ? d.workFocus.filter((x) => x !== id)
        : [...d.workFocus, id].slice(0, 6);
      return { ...d, workFocus };
    });
  }

  function save() {
    const name = draft.name.trim() || "Officer";
    const workFocus =
      draft.workFocus.length > 0 ? draft.workFocus : (role?.competencyIds.slice(0, 4) ?? []);
    setProfile({ ...draft, name, workFocus });
    void navigate({ to: "/" });
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-saffron">
          Step {step + 1} of 3
        </p>
        <h1 className="mt-2 font-display text-3xl font-semibold text-navy">Set your role</h1>
        <p className="mt-2 text-muted">
          Diagnostics and course recommendations follow the chair you sit in, not a generic
          catalogue.
        </p>
      </div>

      {step === 0 && (
        <Card className="space-y-4">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={draft.name}
              onChange={(e) => setDraft({ ...draft, name: e.target.value })}
              placeholder="As you would write it on a note"
              autoComplete="name"
            />
          </div>
          <div>
            <Label htmlFor="designation">Designation</Label>
            <Input
              id="designation"
              value={draft.designation}
              onChange={(e) => setDraft({ ...draft, designation: e.target.value })}
              placeholder="Deputy Secretary, CMO, BDO…"
            />
          </div>
          <div>
            <Label htmlFor="years">Years of service</Label>
            <Input
              id="years"
              type="number"
              min={0}
              max={45}
              value={draft.yearsOfService}
              onChange={(e) =>
                setDraft({ ...draft, yearsOfService: Number(e.target.value) || 0 })
              }
            />
          </div>
          <Button className="w-full" onClick={() => setStep(1)}>
            Continue
          </Button>
        </Card>
      )}

      {step === 1 && (
        <Card className="space-y-4">
          <div>
            <Label htmlFor="ministry">Ministry / department</Label>
            <SelectField
              id="ministry"
              value={draft.ministry}
              onChange={(e) => setDraft({ ...draft, ministry: e.target.value })}
            >
              {MINISTRIES.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </SelectField>
          </div>
          <fieldset>
            <legend className="mb-3 text-sm font-medium">The chair</legend>
            <div className="grid gap-2">
              {ROLES.map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() =>
                    setDraft({
                      ...draft,
                      roleId: r.id,
                      workFocus: r.competencyIds.slice(0, 4),
                    })
                  }
                  className={cn(
                    "rounded-md px-4 py-3 text-left shadow-border transition-colors duration-150",
                    draft.roleId === r.id ? "bg-navy text-primary-foreground" : "bg-paper hover:bg-paper-raised",
                  )}
                >
                  <span className="block font-medium">{r.name}</span>
                  <span
                    className={cn(
                      "mt-0.5 block text-sm",
                      draft.roleId === r.id ? "text-primary-foreground/70" : "text-muted",
                    )}
                  >
                    {r.blurb}
                  </span>
                </button>
              ))}
            </div>
          </fieldset>
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1" onClick={() => setStep(0)}>
              Back
            </Button>
            <Button className="flex-1" onClick={() => setStep(2)}>
              Continue
            </Button>
          </div>
        </Card>
      )}

      {step === 2 && (
        <Card className="space-y-4">
          <p className="text-sm text-muted">
            Pick up to six competencies that the work actually demands this year. We have
            pre-selected those typical of {role?.name}.
          </p>
          <div className="flex flex-wrap gap-2">
            {COMPETENCIES.map((c) => {
              const on = draft.workFocus.includes(c.id);
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => toggleFocus(c.id)}
                  className={cn(
                    "rounded-full px-3 py-2 text-sm font-medium shadow-border",
                    on ? "bg-navy text-primary-foreground" : "bg-paper text-ink",
                  )}
                >
                  {c.name}
                </button>
              );
            })}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1" onClick={() => setStep(1)}>
              Back
            </Button>
            <Button className="flex-1" variant="saffron" onClick={save}>
              Save and go to the desk
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
