import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/cn";
import { scoreAttempt } from "@/lib/quiz-engine";
import { useAppStore, useHydrated } from "@/lib/store";
import type { QuizAttempt } from "@/lib/types";

export const Route = createFileRoute("/quiz/$quizId")({ component: QuizPage });

function QuizPage() {
  const { quizId } = Route.useParams();
  const navigate = useNavigate();
  const hydrated = useHydrated();
  const activeQuiz = useAppStore((s) => s.activeQuiz);
  const saveAttempt = useAppStore((s) => s.saveAttempt);
  const quiz = activeQuiz?.id === quizId ? activeQuiz : null;
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Array<number | null>>([]);

  const filled = useMemo(() => {
    if (!quiz) return answers;
    if (answers.length === quiz.questions.length) return answers;
    return [...answers, ...Array(quiz.questions.length - answers.length).fill(null)];
  }, [answers, quiz]);

  if (!hydrated) {
    return <div className="h-64 animate-pulse rounded-xl bg-navy/8" />;
  }

  if (!quiz) {
    return (
      <div className="mx-auto max-w-lg space-y-4 py-12 text-center">
        <h1 className="font-display text-2xl font-semibold text-navy">This paper has expired</h1>
        <p className="text-muted">
          Diagnostics live only for the sitting. Start a new one from the desk.
        </p>
        <Button asChild>
          <Link to="/diagnose">Back to diagnose</Link>
        </Button>
      </div>
    );
  }

  const question = quiz.questions[index];
  const selected = filled[index];
  const last = index === quiz.questions.length - 1;
  const letters = ["A", "B", "C", "D"] as const;

  function choose(optionIndex: number) {
    setAnswers((prev) => {
      const next = [...filled];
      next[index] = optionIndex;
      return next;
    });
  }

  function submit() {
    if (!quiz) return;
    const scored = scoreAttempt(quiz.questions, filled);
    const attempt: QuizAttempt = {
      id: crypto.randomUUID(),
      quiz,
      answers: filled,
      score: scored.score,
      weakTopics: scored.weakTopics,
      completedAt: new Date().toISOString(),
    };
    saveAttempt(attempt);
    void navigate({ to: "/results/$attemptId", params: { attemptId: attempt.id } });
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-saffron">
          {quiz.source === "ai" ? "Grok paper" : "Curated paper"}
        </p>
        <h1 className="mt-2 font-display text-2xl font-semibold text-navy md:text-3xl">
          {quiz.title}
        </h1>
        <p className="mt-2 text-sm text-muted">
          Question {index + 1} of {quiz.questions.length}
        </p>
        <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-navy/10">
          <div
            className="h-full bg-saffron transition-[width] duration-200 ease-out"
            style={{ width: `${((index + 1) / quiz.questions.length) * 100}%` }}
          />
        </div>
      </div>

      <Card className="space-y-5">
        <p className="font-display text-xl font-medium leading-snug text-navy">{question.stem}</p>
        <div className="grid gap-2">
          {question.options.map((opt, i) => {
            const on = selected === i;
            return (
              <button
                key={opt}
                type="button"
                onClick={() => choose(i)}
                className={cn(
                  "flex min-h-14 items-start gap-3 rounded-md px-4 py-3 text-left text-sm leading-relaxed shadow-border transition-colors duration-150",
                  on ? "bg-navy text-primary-foreground" : "bg-paper hover:bg-paper-raised",
                )}
              >
                <span
                  className={cn(
                    "mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full text-xs font-semibold",
                    on ? "bg-saffron text-saffron-fg" : "bg-navy/8 text-navy",
                  )}
                >
                  {letters[i]}
                </span>
                {opt}
              </button>
            );
          })}
        </div>
      </Card>

      <div className="flex gap-3">
        <Button
          variant="outline"
          className="flex-1"
          disabled={index === 0}
          onClick={() => setIndex((i) => Math.max(0, i - 1))}
        >
          Previous
        </Button>
        {last ? (
          <Button
            variant="saffron"
            className="flex-1"
            disabled={selected === null || selected === undefined}
            onClick={submit}
          >
            Submit paper
          </Button>
        ) : (
          <Button
            className="flex-1"
            disabled={selected === null || selected === undefined}
            onClick={() => setIndex((i) => i + 1)}
          >
            Next
          </Button>
        )}
      </div>
    </div>
  );
}
