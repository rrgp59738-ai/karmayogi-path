import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, Compass, Home, LineChart } from "lucide-react";
import type { ReactNode } from "react";
import { Logo } from "@/components/logo";
import { cn } from "@/lib/cn";
import { roleById } from "@/lib/catalog";
import { useAppStore, useHydrated } from "@/lib/store";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/diagnose", label: "Diagnose", icon: Compass },
  { to: "/courses", label: "Courses", icon: BookOpen },
  { to: "/progress", label: "Progress", icon: LineChart },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hydrated = useHydrated();
  const profile = useAppStore((s) => s.profile);
  const role = profile ? roleById(profile.roleId) : undefined;

  return (
    <div className="flex min-h-dvh flex-col bg-paper text-ink">
      <div className="tricolor h-[3px] w-full" aria-hidden="true" />
      <header className="sticky top-0 z-40 border-b border-line/80 bg-paper/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4">
          <Link to="/" className="shrink-0" aria-label="Karmayogi Path home">
            <Logo />
          </Link>
          <nav className="hidden items-center gap-1 md:flex" aria-label="Primary">
            {NAV.map((item) => {
              const active =
                item.to === "/"
                  ? pathname === "/"
                  : pathname === item.to || pathname.startsWith(`${item.to}/`);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "rounded-sm px-3 py-2 text-sm font-medium transition-colors duration-150",
                    active ? "bg-navy text-primary-foreground" : "text-muted hover:bg-navy/6 hover:text-ink",
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="min-w-0 text-right">
            {hydrated && profile ? (
              <Link to="/onboard" className="block min-w-0">
                <span className="block truncate text-sm font-medium text-navy">{profile.name}</span>
                <span className="block truncate text-xs text-muted">
                  {role?.cadre ?? "Official"} · {profile.designation || "Set designation"}
                </span>
              </Link>
            ) : (
              <Link
                to="/onboard"
                className="text-sm font-medium text-saffron hover:underline"
              >
                Set your role
              </Link>
            )}
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 pb-28 pt-6 md:pb-12 md:pt-8">
        {children}
      </main>
      <nav
        className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-paper/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden"
        aria-label="Mobile"
      >
        <ul className="grid grid-cols-4">
          {NAV.map((item) => {
            const active =
              item.to === "/"
                ? pathname === "/"
                : pathname === item.to || pathname.startsWith(`${item.to}/`);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium",
                    active ? "text-navy" : "text-muted",
                  )}
                >
                  <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
