import { cn } from "@/lib/cn";
import type { HTMLAttributes } from "react";

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "rounded-xl bg-paper-raised p-5 shadow-border md:p-6",
        className,
      )}
      {...props}
    />
  );
}
