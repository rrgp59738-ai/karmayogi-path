import { cn } from "@/lib/cn";
import type { HTMLAttributes } from "react";

export function Badge({
  className,
  tone = "neutral",
  ...props
}: HTMLAttributes<HTMLSpanElement> & {
  tone?: "neutral" | "navy" | "saffron" | "forest" | "weak" | "mid" | "strong" | "untouched";
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide",
        tone === "neutral" && "bg-navy/8 text-navy",
        tone === "navy" && "bg-navy text-primary-foreground",
        tone === "saffron" && "bg-saffron/15 text-saffron",
        tone === "forest" && "bg-forest/12 text-forest",
        tone === "weak" && "bg-danger/12 text-danger",
        tone === "mid" && "bg-warn/15 text-warn",
        tone === "strong" && "bg-forest/12 text-forest",
        tone === "untouched" && "bg-ink/6 text-muted",
        className,
      )}
      {...props}
    />
  );
}
