import { Link } from "@tanstack/react-router";
import { Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { CATEGORY_LABEL, LEVEL_LABEL, competencyById, modulesFor } from "@/lib/catalog";
import { cn } from "@/lib/cn";
import type { Course } from "@/lib/types";

export function CourseCard({
  course,
  progress,
  featured = false,
}: {
  course: Course;
  progress?: { completed: number; total: number; done?: boolean };
  featured?: boolean;
}) {
  const total = modulesFor(course.id).length;
  const primary = competencyById(course.competencyIds[0]);
  return (
    <Link
      to="/courses/$courseId"
      params={{ courseId: course.id }}
      className={cn(
        "group flex flex-col rounded-xl bg-paper-raised p-5 shadow-border transition-[box-shadow,transform] duration-150 hover:shadow-[var(--shadow-border-hover)]",
        featured && "md:p-6",
      )}
    >
      <div className="mb-4 flex items-center justify-between gap-2">
        <Badge>{CATEGORY_LABEL[course.category]}</Badge>
        <span className="inline-flex items-center gap-1 text-xs text-muted">
          <Clock className="size-3.5" />
          {course.durationMin} min
        </span>
      </div>
      <h3 className="font-display text-xl font-semibold tracking-tight text-navy group-hover:text-saffron">
        {course.title}
      </h3>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-muted">{course.subtitle}</p>
      <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-muted">
        <span>{LEVEL_LABEL[course.level]}</span>
        <span aria-hidden="true">·</span>
        <span>{primary?.short}</span>
        {progress && total > 0 && (
          <>
            <span aria-hidden="true">·</span>
            <span className={progress.done ? "text-forest" : undefined}>
              {progress.done ? "Completed" : `${progress.completed}/${total} modules`}
            </span>
          </>
        )}
      </div>
    </Link>
  );
}
