import { cn } from "@/lib/cn";

export function Logo({ className, markOnly = false }: { className?: string; markOnly?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5 text-navy", className)}>
      <svg
        viewBox="0 0 32 32"
        className="size-8 shrink-0"
        aria-hidden="true"
      >
        <rect width="32" height="32" rx="8" className="fill-navy" />
        <circle cx="22" cy="9" r="2.2" className="fill-saffron" />
        <path
          d="M8 23c3.2-1 5.4-4.2 6.2-8.2.6-3 2.2-5.4 5.4-6.4"
          fill="none"
          stroke="currentColor"
          className="stroke-primary-foreground"
          strokeWidth="1.8"
          strokeLinecap="round"
        />
        <path
          d="M8 23c4.5.4 8.6-1.4 11.4-5"
          fill="none"
          stroke="currentColor"
          className="stroke-saffron"
          strokeWidth="1.6"
          strokeLinecap="round"
        />
      </svg>
      {!markOnly && (
        <span className="leading-tight">
          <span className="block font-display text-[1.05rem] font-semibold tracking-tight">
            Karmayogi Path
          </span>
          <span className="block text-[0.68rem] font-medium uppercase tracking-[0.16em] text-muted">
            कर्मयोगी पथ
          </span>
        </span>
      )}
    </span>
  );
}
