import {
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
} from "recharts";
import { COMPETENCIES } from "@/lib/catalog";
import type { CompetencyScore } from "@/lib/types";

export function GapRadar({ scores }: { scores: Record<string, CompetencyScore> }) {
  const data = COMPETENCIES.map((c) => ({
    name: c.short,
    score: scores[c.id]?.score ?? 0,
  }));

  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={data} cx="50%" cy="50%" outerRadius="72%">
          <PolarGrid stroke="var(--color-line)" />
          <PolarAngleAxis
            dataKey="name"
            tick={{ fill: "var(--color-muted)", fontSize: 11 }}
          />
          <PolarRadiusAxis
            angle={90}
            domain={[0, 100]}
            tick={false}
            axisLine={false}
          />
          <Radar
            name="Proficiency"
            dataKey="score"
            stroke="var(--color-navy)"
            fill="var(--color-navy)"
            fillOpacity={0.18}
            strokeWidth={2}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
